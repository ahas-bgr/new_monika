<?php

namespace Database\Seeders;

use App\Models\BastDocument;
use App\Models\Client;
use App\Models\CompanySetting;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\PendingRequirement;
use App\Models\Project;
use App\Models\ProjectStatusLog;
use App\Models\PurchaseOrder;
use App\Models\Quotation;
use App\Models\QuotationItem;
use App\Models\Task;
use App\Models\User;
use Illuminate\Database\Seeder;

class MonikaSeeder extends Seeder
{
    public function run(): void
    {
        /* ---------- Pengguna ---------- */
        $admin = User::create([
            'name' => 'Administrator', 'email' => 'admin@monika.test',
            'password' => 'admin123', 'role' => 'admin', 'is_active' => true,
        ]);
        $budi = User::create([
            'name' => 'Budi Santoso', 'email' => 'budi@monika.test',
            'password' => 'staff123', 'role' => 'staff', 'is_active' => true,
        ]);
        $sari = User::create([
            'name' => 'Sari Wulandari', 'email' => 'sari@monika.test',
            'password' => 'staff123', 'role' => 'staff', 'is_active' => true,
        ]);

        /* ---------- Perusahaan ---------- */
        CompanySetting::create([
            'id' => 1,
            'name' => 'PT Dikari Tata Udara Indonesia',
            'address' => 'Jl. Contoh No. 1, Jakarta',
            'npwp' => '00.000.000.0-000.000',
            'bank_info' => 'Bank BCA 1234567890 a.n. PT Dikari Tata Udara Indonesia',
        ]);

        /* ---------- Klien ---------- */
        $rudi = Client::create(['name' => 'Rudi Hartono', 'company' => 'PT Maju Bersama', 'address' => 'Jakarta Selatan', 'email' => 'rudi@majubersama.co.id', 'phone' => '0812-1111-2222']);
        $dewi = Client::create(['name' => 'Dewi Lestari', 'company' => 'CV Sinar Abadi', 'address' => 'Tangerang', 'email' => 'dewi@sinarabadi.id', 'phone' => '0813-3333-4444']);
        $andi = Client::create(['name' => 'Andi Wijaya', 'company' => 'RS Sehat Sentosa', 'address' => 'Bekasi', 'email' => 'andi@sehatsentosa.com', 'phone' => '0821-5555-6666']);

        $log = function (Project $p, ?string $from, string $to, User $u, string $note, int $daysAgo, bool $ovr = false, ?array $skipped = null) {
            ProjectStatusLog::forceCreate([
                'project_id' => $p->id, 'from_status' => $from, 'to_status' => $to,
                'user_id' => $u->id, 'note' => $note, 'is_override' => $ovr,
                'skipped_requirements' => $skipped, 'created_at' => now()->subDays($daysAgo),
            ]);
        };

        $setDates = function (Project $p, int $createdDaysAgo, int $updatedDaysAgo) {
            $p->timestamps = false;
            $p->forceFill([
                'created_at' => now()->subDays($createdDaysAgo),
                'updated_at' => now()->subDays($updatedDaysAgo),
            ])->save();
            $p->timestamps = true;
        };

        /* ---------- Proyek 1: sph_draft (baru) ---------- */
        $p1 = Project::create([
            'client_id' => $rudi->id, 'name' => 'Instalasi VRV Gedung Kantor A',
            'description' => 'Instalasi sistem VRV 3 lantai', 'status' => 'sph_draft',
            'value_total' => 85000000, 'created_by' => $budi->id,
        ]);
        $log($p1, null, 'sph_draft', $budi, 'Proyek dibuat', 2);
        $setDates($p1, 2, 2);

        /* ---------- Proyek 2: menunggu_po, macet 12 hari ---------- */
        $p2 = Project::create([
            'client_id' => $dewi->id, 'name' => 'PM HVAC Kontrak Tahunan 2026',
            'description' => 'Preventive maintenance 12 kunjungan', 'status' => 'menunggu_po',
            'value_total' => 48000000, 'created_by' => $budi->id,
        ]);
        Quotation::create([
            'project_id' => $p2->id, 'number' => 'SPH/001/VI/2026',
            'date' => today()->subDays(25), 'valid_until' => today()->addDays(20),
            'ppn_percent' => 11, 'status' => 'terkirim', 'sent_at' => now()->subDays(12),
        ]);
        $log($p2, null, 'sph_draft', $budi, 'Proyek dibuat', 30);
        $log($p2, 'sph_draft', 'menunggu_po', $budi, 'SPH terkirim via email', 12);
        $setDates($p2, 30, 12);

        /* ---------- Proyek 3: pengerjaan dengan OVERRIDE (PO menyusul) ---------- */
        $p3 = Project::create([
            'client_id' => $rudi->id, 'name' => 'Pemasangan Chiller Pabrik Cikarang',
            'description' => 'Supply & install chiller 150 TR', 'status' => 'pengerjaan',
            'value_total' => 320000000, 'created_by' => $admin->id,
        ]);
        $q3 = Quotation::create([
            'project_id' => $p3->id, 'number' => 'SPH/002/VI/2026',
            'date' => today()->subDays(14), 'valid_until' => today()->addDays(16),
            'ppn_percent' => 11, 'status' => 'terkirim', 'sent_at' => now()->subDays(13),
        ]);
        QuotationItem::create(['quotation_id' => $q3->id, 'description' => 'Chiller air cooled 150 TR', 'qty' => 1, 'unit' => 'unit', 'unit_price' => 260000000]);
        QuotationItem::create(['quotation_id' => $q3->id, 'description' => 'Instalasi & commissioning', 'qty' => 1, 'unit' => 'lot', 'unit_price' => 60000000]);
        $log($p3, null, 'sph_draft', $admin, 'Proyek dibuat', 15);
        $log($p3, 'sph_draft', 'menunggu_po', $budi, 'SPH terkirim', 13);
        $log($p3, 'menunggu_po', 'pengerjaan', $admin,
            'PO menyusul — klien minta pekerjaan dimulai per telepon Bpk. Rudi, PO resmi sedang diproses purchasing',
            8, true, ['po_document']);
        PendingRequirement::forceCreate([
            'project_id' => $p3->id, 'type' => 'po_document', 'status' => 'open',
            'created_by' => $admin->id, 'created_at' => now()->subDays(8),
        ]);
        Task::create(['project_id' => $p3->id, 'title' => 'Mobilisasi alat & material', 'deadline' => today()->subDays(5), 'status' => 'done', 'assignee_id' => $budi->id]);
        Task::create(['project_id' => $p3->id, 'title' => 'Pemasangan pondasi chiller', 'deadline' => today()->subDays(2), 'status' => 'done', 'assignee_id' => $budi->id]);
        Task::create(['project_id' => $p3->id, 'title' => 'Instalasi pemipaan chilled water', 'deadline' => today()->addDays(5), 'status' => 'in_progress', 'assignee_id' => $sari->id]);
        Task::create(['project_id' => $p3->id, 'title' => 'Testing & commissioning', 'deadline' => today()->addDays(12), 'status' => 'todo', 'assignee_id' => $budi->id]);
        $setDates($p3, 15, 1);

        /* ---------- Proyek 4: bast (semua task selesai) ---------- */
        $p4 = Project::create([
            'client_id' => $dewi->id, 'name' => 'Retrofit Ducting Mall Sentral',
            'description' => 'Penggantian ducting food court', 'status' => 'bast',
            'value_total' => 95000000, 'created_by' => $budi->id,
        ]);
        Quotation::create([
            'project_id' => $p4->id, 'number' => 'SPH/003/V/2026',
            'date' => today()->subDays(38), 'ppn_percent' => 11,
            'status' => 'po_diterima', 'sent_at' => now()->subDays(36),
        ]);
        PurchaseOrder::create(['project_id' => $p4->id, 'number' => 'PO-MS/0455/2026', 'date' => today()->subDays(33)]);
        Task::create(['project_id' => $p4->id, 'title' => 'Pembongkaran ducting lama', 'status' => 'done', 'assignee_id' => $budi->id]);
        Task::create(['project_id' => $p4->id, 'title' => 'Fabrikasi & pemasangan ducting baru', 'status' => 'done', 'assignee_id' => $sari->id]);
        Task::create(['project_id' => $p4->id, 'title' => 'Balancing & finishing', 'status' => 'done', 'assignee_id' => $budi->id]);
        $log($p4, null, 'sph_draft', $budi, 'Proyek dibuat', 40);
        $log($p4, 'sph_draft', 'menunggu_po', $budi, 'SPH terkirim', 36);
        $log($p4, 'menunggu_po', 'pengerjaan', $budi, 'PO diterima', 33);
        $log($p4, 'pengerjaan', 'bast', $budi, 'Seluruh pekerjaan selesai 100%', 3);
        $setDates($p4, 40, 3);

        /* ---------- Proyek 5: menunggu_pembayaran, invoice jatuh tempo, bayar parsial ---------- */
        $p5 = Project::create([
            'client_id' => $andi->id, 'name' => 'Overhaul AHU RS Sehat Sentosa',
            'description' => 'Overhaul 4 unit AHU gedung rawat inap', 'status' => 'menunggu_pembayaran',
            'value_total' => 64000000, 'created_by' => $sari->id,
        ]);
        Quotation::create([
            'project_id' => $p5->id, 'number' => 'SPH/004/IV/2026',
            'date' => today()->subDays(68), 'ppn_percent' => 11,
            'status' => 'po_diterima', 'sent_at' => now()->subDays(66),
        ]);
        PurchaseOrder::create(['project_id' => $p5->id, 'number' => 'PO/RSS/2026/112', 'date' => today()->subDays(62)]);
        Task::create(['project_id' => $p5->id, 'title' => 'Overhaul AHU 1 & 2', 'status' => 'done']);
        Task::create(['project_id' => $p5->id, 'title' => 'Overhaul AHU 3 & 4', 'status' => 'done']);
        BastDocument::create(['project_id' => $p5->id, 'number' => 'BAST/012/2026', 'date' => today()->subDays(30), 'signed_at' => now()->subDays(28)]);
        $inv5 = Invoice::create([
            'project_id' => $p5->id, 'number' => 'INV/021/V/2026', 'invoice_type' => 'full',
            'date' => today()->subDays(26), 'due_date' => today()->subDays(6),
            'total' => 64000000, 'status' => 'sebagian', 'sent_at' => now()->subDays(25),
        ]);
        Payment::create(['invoice_id' => $inv5->id, 'date' => today()->subDays(10), 'amount' => 32000000, 'method' => 'Transfer BCA', 'recorded_by' => $admin->id]);
        $log($p5, null, 'sph_draft', $sari, 'Proyek dibuat', 70);
        $log($p5, 'sph_draft', 'menunggu_po', $sari, 'SPH terkirim', 66);
        $log($p5, 'menunggu_po', 'pengerjaan', $sari, 'PO diterima', 62);
        $log($p5, 'pengerjaan', 'bast', $sari, 'Pekerjaan selesai', 32);
        $log($p5, 'bast', 'invoicing', $admin, 'BAST ditandatangani kedua pihak', 28);
        $log($p5, 'invoicing', 'menunggu_pembayaran', $sari, 'Invoice terkirim ke bagian keuangan RS', 25);
        $setDates($p5, 70, 10);

        /* ---------- Proyek 6: selesai (riwayat lengkap) ---------- */
        $p6 = Project::create([
            'client_id' => $dewi->id, 'name' => 'Instalasi Split Duct Ruko Blok C',
            'description' => 'Instalasi 6 unit split duct', 'status' => 'selesai',
            'value_total' => 42000000, 'created_by' => $budi->id,
        ]);
        Quotation::create([
            'project_id' => $p6->id, 'number' => 'SPH/005/III/2026',
            'date' => today()->subDays(98), 'ppn_percent' => 11,
            'status' => 'po_diterima', 'sent_at' => now()->subDays(96),
        ]);
        PurchaseOrder::create(['project_id' => $p6->id, 'number' => 'PO-SA/0090/2026', 'date' => today()->subDays(92)]);
        Task::create(['project_id' => $p6->id, 'title' => 'Instalasi indoor & outdoor unit', 'status' => 'done']);
        Task::create(['project_id' => $p6->id, 'title' => 'Instalasi ducting & diffuser', 'status' => 'done']);
        Task::create(['project_id' => $p6->id, 'title' => 'Test & serah terima', 'status' => 'done']);
        BastDocument::create(['project_id' => $p6->id, 'number' => 'BAST/008/2026', 'date' => today()->subDays(55), 'signed_at' => now()->subDays(54)]);
        $inv6 = Invoice::create([
            'project_id' => $p6->id, 'number' => 'INV/015/IV/2026', 'invoice_type' => 'full',
            'date' => today()->subDays(52), 'due_date' => today()->subDays(22),
            'total' => 42000000, 'status' => 'lunas', 'sent_at' => now()->subDays(51),
        ]);
        Payment::create(['invoice_id' => $inv6->id, 'date' => today()->subDays(20), 'amount' => 42000000, 'method' => 'Transfer Mandiri', 'recorded_by' => $admin->id]);
        $log($p6, null, 'sph_draft', $budi, 'Proyek dibuat', 100);
        $log($p6, 'sph_draft', 'menunggu_po', $budi, 'SPH terkirim', 96);
        $log($p6, 'menunggu_po', 'pengerjaan', $budi, 'PO diterima', 92);
        $log($p6, 'pengerjaan', 'bast', $budi, 'Pekerjaan selesai', 58);
        $log($p6, 'bast', 'invoicing', $admin, 'BAST ditandatangani', 54);
        $log($p6, 'invoicing', 'menunggu_pembayaran', $budi, 'Invoice terkirim', 51);
        $log($p6, 'menunggu_pembayaran', 'selesai', $admin, 'Pembayaran lunas diterima', 20);
        $setDates($p6, 100, 20);
    }
}
