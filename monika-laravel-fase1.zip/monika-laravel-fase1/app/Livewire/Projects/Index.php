<?php

namespace App\Livewire\Projects;

use App\Models\Client;
use App\Models\Project;
use App\Services\ProjectStateService;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Component;

#[Title('Proyek')]
class Index extends Component
{
    #[Url(as: 'q')]
    public string $search = '';

    #[Url]
    public string $status = '';

    #[Url]
    public int $client = 0;

    #[Url]
    public string $d1 = '';

    #[Url]
    public string $d2 = '';

    public function resetFilters(): void
    {
        $this->reset(['search', 'status', 'client', 'd1', 'd2']);
    }

    public function render()
    {
        $projects = Project::with('client:id,name,company')
            ->withCount(['openRequirements as pending_open'])
            ->when($this->search !== '', function ($q) {
                $q->where(function ($w) {
                    $w->where('name', 'like', "%{$this->search}%")
                        ->orWhereHas('client', fn ($c) => $c
                            ->where('name', 'like', "%{$this->search}%")
                            ->orWhere('company', 'like', "%{$this->search}%"));
                });
            })
            ->when($this->status !== '', fn ($q) => $q->where('status', $this->status))
            ->when($this->client > 0, fn ($q) => $q->where('client_id', $this->client))
            ->when($this->d1 !== '', fn ($q) => $q->whereDate('created_at', '>=', $this->d1))
            ->when($this->d2 !== '', fn ($q) => $q->whereDate('created_at', '<=', $this->d2))
            ->latest('updated_at')
            ->limit(200)
            ->get();

        return view('livewire.projects.index', [
            'projects' => $projects,
            'clients'  => Client::orderBy('name')->get(['id', 'name']),
            'statuses' => ProjectStateService::STATUSES,
        ]);
    }
}
