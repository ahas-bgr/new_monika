<?php

namespace App\Livewire;

use App\Models\CompanySetting;
use App\Models\Invoice;
use App\Models\PendingRequirement;
use App\Models\Project;
use App\Services\ProjectStateService;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Component;

#[Title('Dashboard')]
class Dashboard extends Component
{
    #[Url(as: 'q')]
    public string $search = '';

    #[Url(as: 'status')]
    public string $filterStatus = '';

    public function render()
    {
        $settings  = CompanySetting::current();
        $stuckDays = max(1, (int) $settings->stuck_threshold_days);

        $counts = Project::query()
            ->selectRaw('status, COUNT(*) as c')
            ->groupBy('status')
            ->pluck('c', 'status');

        $menyusul = PendingRequirement::with('project:id,name')
            ->where('status', 'open')
            ->whereHas('project')
            ->oldest('created_at')
            ->limit(8)
            ->get();

        $macet = Project::query()
            ->whereNotIn('status', ['selesai', ProjectStateService::CANCELLED])
            ->where('updated_at', '<', now()->subDays($stuckDays))
            ->oldest('updated_at')
            ->limit(8)
            ->get();

        $piutang = Invoice::with('project:id,name')
            ->where('status', '!=', 'lunas')
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<', today())
            ->whereHas('project')
            ->oldest('due_date')
            ->limit(8)
            ->get();

        $projects = Project::with('client:id,name,company')
            ->withCount(['openRequirements as pending_open'])
            ->when($this->search !== '', function ($q) {
                $q->where(function ($w) {
                    $w->where('name', 'like', "%{$this->search}%")
                        ->orWhereHas('client', fn ($c) => $c
                            ->where('name', 'like', "%{$this->search}%")
                            ->orWhere('company', 'like', "%{$this->search}%"));
                });
            })
            ->when(
                $this->filterStatus !== '',
                fn ($q) => $q->where('status', $this->filterStatus),
                fn ($q) => $q->whereNotIn('status', ['selesai', ProjectStateService::CANCELLED])
            )
            ->latest('updated_at')
            ->limit(50)
            ->get();

        return view('livewire.dashboard', [
            'settings'  => $settings,
            'stuckDays' => $stuckDays,
            'counts'    => $counts,
            'menyusul'  => $menyusul,
            'macet'     => $macet,
            'piutang'   => $piutang,
            'projects'  => $projects,
            'statuses'  => ProjectStateService::STATUSES,
            'reqLabels' => ProjectStateService::REQ_LABELS,
        ]);
    }
}
