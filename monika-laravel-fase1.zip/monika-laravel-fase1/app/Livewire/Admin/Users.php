<?php

namespace App\Livewire\Admin;

use App\Models\User;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Pengguna')]
class Users extends Component
{
    public string $name = '';
    public string $email = '';
    public string $password = '';
    public string $role = 'staff';

    /** @var array<int, string> password baru per user (form reset) */
    public array $resetPasswords = [];

    public function addUser(): void
    {
        $data = $this->validate([
            'name'     => ['required', 'string', 'max:120'],
            'email'    => ['required', 'email', 'max:160', 'unique:users,email'],
            'password' => ['required', 'string', 'min:6'],
            'role'     => ['required', 'in:admin,staff'],
        ]);

        User::create($data + ['is_active' => true]);

        $this->reset(['name', 'email', 'password']);
        $this->role = 'staff';
        session()->flash('ok', 'Pengguna baru ditambahkan.');
    }

    public function toggleActive(int $userId): void
    {
        if ($userId === auth()->id()) {
            session()->flash('warn', 'Tidak bisa menonaktifkan akun sendiri.');

            return;
        }

        $user = User::findOrFail($userId);
        $user->update(['is_active' => ! $user->is_active]);
        session()->flash('ok', 'Status pengguna diubah.');
    }

    public function resetPassword(int $userId): void
    {
        $password = trim($this->resetPasswords[$userId] ?? '');

        if (strlen($password) < 6) {
            session()->flash('err', 'Password baru minimal 6 karakter.');

            return;
        }

        User::findOrFail($userId)->update(['password' => $password]);
        unset($this->resetPasswords[$userId]);
        session()->flash('ok', 'Password diatur ulang.');
    }

    public function render()
    {
        return view('livewire.admin.users', [
            'users' => User::orderBy('role')->orderBy('name')->get(),
        ]);
    }
}
