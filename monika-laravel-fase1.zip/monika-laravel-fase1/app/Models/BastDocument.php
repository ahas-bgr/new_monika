<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BastDocument extends Model
{
    protected $fillable = ['project_id', 'number', 'date', 'signed_at', 'signed_file_path'];

    protected function casts(): array
    {
        return ['date' => 'date', 'signed_at' => 'datetime'];
    }
}
