<?php

namespace App\Services;

use App\Models\PendingRequirement;
use App\Models\Project;
use App\Models\ProjectStatusLog;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Throwable;

/**
 * Satu-satunya pintu untuk semua transisi status proyek.
 * Aturan gating, override, rollback, pembatalan, log, dan
 * hutang dokumen (pending requirements) hidup di sini —
 * jangan pernah mengubah kolom projects.status di tempat lain.
 */
class ProjectStateService
{
    public const STATUSES = [
        'sph_draft'           => 'SPH Draft',
        'menunggu_po'         => 'Menunggu PO',
        'pengerjaan'          => 'Pengerjaan',
        'bast'                => 'BAST',
        'invoicing'           => 'Invoicing',
        'menunggu_pembayaran' => 'Menunggu Pembayaran',
        'selesai'             => 'Selesai',
    ];

    public const CANCELLED = 'dibatalkan';

    /** Syarat untuk KELUAR dari tiap status. */
    public const STAGE_REQUIREMENTS = [
        'sph_draft'           => ['sph_sent'],
        'menunggu_po'         => ['po_document'],
        'pengerjaan'          => ['tasks_done'],
        'bast'                => ['bast_signed'],
        'invoicing'           => ['invoice_sent'],
        'menunggu_pembayaran' => ['payment_settled'],
    ];

    public const REQ_LABELS = [
        'sph_sent'        => 'SPH belum ditandai terkirim',
        'po_document'     => 'PO belum diinput / diupload',
        'tasks_done'      => 'Task pengerjaan belum 100% selesai',
        'bast_signed'     => 'BAST belum ditandatangani',
        'invoice_sent'    => 'Invoice belum diterbitkan & dikirim',
        'payment_settled' => 'Pembayaran belum lunas',
    ];

    /** Syarat menyangkut uang: TIDAK BISA dilewati walau override. */
    public const NON_OVERRIDABLE = ['payment_settled'];

    /* ---------------- Helper status ---------------- */

    public static function label(string $status): string
    {
        return $status === self::CANCELLED ? 'Dibatalkan' : (self::STATUSES[$status] ?? $status);
    }

    public static function index(string $status): int
    {
        $i = array_search($status, array_keys(self::STATUSES), true);

        return $i === false ? -1 : $i;
    }

    public static function next(string $status): ?string
    {
        $keys = array_keys(self::STATUSES);
        $i = array_search($status, $keys, true);

        return ($i !== false && $i < count($keys) - 1) ? $keys[$i + 1] : null;
    }

    public static function prev(string $status): ?string
    {
        $keys = array_keys(self::STATUSES);
        $i = array_search($status, $keys, true);

        return ($i !== false && $i > 0) ? $keys[$i - 1] : null;
    }

    /* ---------------- Pemeriksaan syarat ---------------- */

    public function requirementMet(Project $project, string $req): bool
    {
        return match ($req) {
            'sph_sent' => $project->quotations()
                ->where('status', 'terkirim')->whereNotNull('sent_at')->exists(),

            'po_document' => $project->purchaseOrders()->exists(),

            'tasks_done' => $project->tasks()->count() > 0
                && ! $project->tasks()->where('status', '!=', 'done')->exists(),

            'bast_signed' => $project->bastDocuments()->whereNotNull('signed_at')->exists(),

            'invoice_sent' => $project->invoices()->whereNotNull('sent_at')->exists(),

            'payment_settled' => $this->paymentSettled($project),

            default => false,
        };
    }

    protected function paymentSettled(Project $project): bool
    {
        $billed = (float) $project->invoices()->sum('total');
        $paid   = (float) $project->payments()->sum('amount');

        return $billed > 0 && $paid >= $billed;
    }

    /** @return string[] syarat yang belum terpenuhi untuk maju dari status saat ini */
    public function unmetRequirements(Project $project): array
    {
        $unmet = [];
        foreach (self::STAGE_REQUIREMENTS[$project->status] ?? [] as $req) {
            if (! $this->requirementMet($project, $req)) {
                $unmet[] = $req;
            }
        }

        return $unmet;
    }

    /* ---------------- Transisi ---------------- */

    protected function log(
        Project $project, ?string $from, string $to, User $user,
        string $note = '', bool $isOverride = false, array $skipped = []
    ): void {
        ProjectStatusLog::create([
            'project_id'           => $project->id,
            'from_status'          => $from,
            'to_status'            => $to,
            'user_id'              => $user->id,
            'note'                 => $note,
            'is_override'          => $isOverride,
            'skipped_requirements' => $skipped ?: null,
        ]);
    }

    /**
     * Majukan proyek satu tahap.
     *
     * @return array{0: bool, 1: string} [sukses, pesan]
     */
    public function advance(Project $project, User $user, bool $override = false, string $note = ''): array
    {
        $to = self::next($project->status);
        if (! $to) {
            return [false, 'Proyek sudah di tahap terakhir.'];
        }

        $unmet = $this->unmetRequirements($project);

        // Jaring pengaman terakhir: arsip harus selalu lengkap.
        if ($to === 'selesai' && $project->openRequirements()->exists()) {
            return [false, 'Proyek tidak bisa Selesai: masih ada dokumen menyusul yang belum dilengkapi.'];
        }

        foreach ($unmet as $req) {
            if (in_array($req, self::NON_OVERRIDABLE, true)) {
                return [false, 'Syarat "' . self::REQ_LABELS[$req] . '" tidak bisa dilewati, walau dengan override.'];
            }
        }

        if ($unmet && ! $override) {
            $labels = array_map(fn ($r) => self::REQ_LABELS[$r], $unmet);

            return [false, 'Syarat belum terpenuhi: ' . implode('; ', $labels) . '.'];
        }

        if ($override) {
            if (! $user->isAdmin()) {
                return [false, 'Override hanya bisa dilakukan admin.'];
            }
            if (mb_strlen(trim($note)) < 10) {
                return [false, 'Alasan override wajib diisi (minimal 10 karakter).'];
            }
        }

        try {
            DB::transaction(function () use ($project, $user, $to, $note, $override, $unmet) {
                $from = $project->status;
                $project->forceFill(['status' => $to])->save();

                $this->log($project, $from, $to, $user, $note, $override && $unmet, $unmet);

                if ($override) {
                    foreach ($unmet as $req) {
                        PendingRequirement::create([
                            'project_id' => $project->id,
                            'type'       => $req,
                            'status'     => 'open',
                            'created_by' => $user->id,
                        ]);
                    }
                }
            });
        } catch (Throwable $t) {
            return [false, 'Gagal menyimpan transisi: ' . $t->getMessage()];
        }

        $msg = 'Proyek maju ke tahap ' . self::label($to) . '.';
        if ($override && $unmet) {
            $msg .= ' Syarat yang dilewati dicatat sebagai dokumen menyusul.';
        }

        return [true, $msg];
    }

    /** Mundur satu tahap (koreksi, khusus admin, wajib alasan). */
    public function rollback(Project $project, User $user, string $note): array
    {
        if (! $user->isAdmin()) {
            return [false, 'Rollback hanya bisa dilakukan admin.'];
        }
        if (mb_strlen(trim($note)) < 10) {
            return [false, 'Alasan rollback wajib diisi (minimal 10 karakter).'];
        }
        $to = self::prev($project->status);
        if (! $to) {
            return [false, 'Proyek sudah di tahap pertama.'];
        }

        $from = $project->status;
        $project->forceFill(['status' => $to])->save();
        $this->log($project, $from, $to, $user, '[ROLLBACK] ' . $note);

        return [true, 'Proyek dikembalikan ke tahap ' . self::label($to) . '.'];
    }

    /** Batalkan proyek (khusus admin, wajib alasan). */
    public function cancel(Project $project, User $user, string $note): array
    {
        if (! $user->isAdmin()) {
            return [false, 'Pembatalan hanya bisa dilakukan admin.'];
        }
        if (mb_strlen(trim($note)) < 10) {
            return [false, 'Alasan pembatalan wajib diisi (minimal 10 karakter).'];
        }

        $from = $project->status;
        $project->forceFill(['status' => self::CANCELLED, 'cancelled_reason' => $note])->save();
        $this->log($project, $from, self::CANCELLED, $user, $note);

        return [true, 'Proyek dibatalkan.'];
    }

    /** Tandai satu hutang dokumen terpenuhi. */
    public function resolveRequirement(int $requirementId, User $user, string $note = ''): array
    {
        $updated = PendingRequirement::where('id', $requirementId)
            ->where('status', 'open')
            ->update([
                'status'       => 'resolved',
                'resolved_at'  => now(),
                'resolved_by'  => $user->id,
                'resolve_note' => $note,
            ]);

        if (! $updated) {
            return [false, 'Dokumen menyusul tidak ditemukan atau sudah dilengkapi.'];
        }

        return [true, 'Dokumen menyusul ditandai lengkap.'];
    }
}
