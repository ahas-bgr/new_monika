@php use App\Services\ProjectStateService as P; @endphp
<div>
  <div class="page-head">
    <div>
      <h1>Dashboard</h1>
      <div class="sub">{{ $settings->name }} · @tgl(today())</div>
    </div>
    <a class="btn btn-primary" href="{{ route('projects.create') }}" wire:navigate>+ Proyek Baru</a>
  </div>

  <div class="status-grid">
    @foreach ($statuses as $key => $label)
      <button type="button" class="status-card {{ $key === 'selesai' ? 't-done' : '' }}"
              wire:click="$set('filterStatus', '{{ $key }}')"
              style="text-align:left;cursor:pointer;font:inherit">
        <div class="num">{{ $counts[$key] ?? 0 }}</div>
        <div class="lbl">{{ $label }}</div>
      </button>
    @endforeach
    <button type="button" class="status-card t-cancel"
            wire:click="$set('filterStatus', '{{ P::CANCELLED }}')"
            style="text-align:left;cursor:pointer;font:inherit">
      <div class="num">{{ $counts[P::CANCELLED] ?? 0 }}</div>
      <div class="lbl">Dibatalkan</div>
    </button>
  </div>

  <div class="attn-grid">
    <div class="card attn">
      <div class="card-head"><h2>⚠ Dokumen Menyusul</h2><span class="badge b-amber">{{ $menyusul->count() }}</span></div>
      @if ($menyusul->isEmpty())
        <div class="empty">Tidak ada — semua dokumen lengkap. 👍</div>
      @else
        <ul>
          @foreach ($menyusul as $m)
            <li>
              <a href="{{ route('projects.show', $m->project_id) }}" wire:navigate><b>{{ $m->project->name }}</b></a>
              <div class="meta">{{ $reqLabels[$m->type] ?? $m->type }} · sudah <b>@umurhari($m->created_at) hari</b></div>
            </li>
          @endforeach
        </ul>
      @endif
    </div>

    <div class="card attn stuck">
      <div class="card-head"><h2>⏳ Proyek Macet &gt; {{ $stuckDays }} hari</h2><span class="badge b-purple">{{ $macet->count() }}</span></div>
      @if ($macet->isEmpty())
        <div class="empty">Semua proyek bergerak sesuai jadwal.</div>
      @else
        <ul>
          @foreach ($macet as $m)
            <li>
              <a href="{{ route('projects.show', $m) }}" wire:navigate><b>{{ $m->name }}</b></a>
              <div class="meta">Diam di tahap {{ P::label($m->status) }} selama <b>@umurhari($m->updated_at) hari</b></div>
            </li>
          @endforeach
        </ul>
      @endif
    </div>

    <div class="card attn overdue">
      <div class="card-head"><h2>💰 Piutang Jatuh Tempo</h2><span class="badge b-coral">{{ $piutang->count() }}</span></div>
      @if ($piutang->isEmpty())
        <div class="empty">Tidak ada invoice yang melewati jatuh tempo.</div>
      @else
        <ul>
          @foreach ($piutang as $iv)
            <li>
              <a href="{{ route('projects.show', $iv->project_id) }}" wire:navigate><b>{{ $iv->number }}</b></a>
              — {{ $iv->project->name }}
              <div class="meta">Sisa <b>@rupiah($iv->total - $iv->paidAmount())</b> · lewat <b>@umurhari($iv->due_date) hari</b> dari jatuh tempo</div>
            </li>
          @endforeach
        </ul>
      @endif
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-head">
      <h2>{{ $filterStatus !== '' ? 'Proyek: ' . P::label($filterStatus) : 'Proyek Aktif' }}</h2>
      <div class="filters" style="margin:0">
        <input type="text" wire:model.live.debounce.400ms="search" placeholder="Cari proyek / klien…" style="width:190px">
        <select wire:model.live="filterStatus">
          <option value="">Semua aktif</option>
          @foreach ($statuses as $key => $label)
            <option value="{{ $key }}">{{ $label }}</option>
          @endforeach
          <option value="{{ P::CANCELLED }}">Dibatalkan</option>
        </select>
      </div>
    </div>
    <div class="card-body tight table-scroll" wire:loading.class="muted">
      <table class="table">
        <thead><tr>
          <th>Proyek</th><th>Klien</th><th>Pipeline</th><th>Status</th><th class="right">Nilai</th><th>Update</th>
        </tr></thead>
        <tbody>
        @forelse ($projects as $p)
          <tr wire:key="proj-{{ $p->id }}">
            <td>
              <a href="{{ route('projects.show', $p) }}" wire:navigate><b>{{ $p->name }}</b></a>
              @if ($p->pending_open > 0)
                <span class="badge b-amber" title="Ada dokumen menyusul">⚠ {{ $p->pending_open }} menyusul</span>
              @endif
            </td>
            <td>{{ $p->client->name }}<div class="small muted">{{ $p->client->company }}</div></td>
            <td><x-stepper :status="$p->status" /></td>
            <td><x-status-badge :status="$p->status" /></td>
            <td class="right">@rupiah($p->value_total)</td>
            <td class="small muted">@tgl($p->updated_at)</td>
          </tr>
        @empty
          <tr><td colspan="6" class="muted" style="padding:20px">
            Belum ada proyek pada filter ini.
            <a href="{{ route('projects.create') }}" wire:navigate>Buat proyek baru</a>.
          </td></tr>
        @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>
