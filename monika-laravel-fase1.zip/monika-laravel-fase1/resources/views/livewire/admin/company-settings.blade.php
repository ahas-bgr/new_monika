<div>
  <div class="page-head">
    <div><h1>Pengaturan Perusahaan</h1>
      <div class="sub">Dipakai di kop PDF SPH, BAST, dan Invoice (Fase 2–3)</div></div>
  </div>

  <div class="card" style="max-width:720px">
    <div class="card-body">
      <form wire:submit="save">
        <div class="field"><label>Nama Perusahaan</label>
          <input type="text" wire:model="name">
          @error('name') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
        </div>
        <div class="field"><label>Alamat</label>
          <textarea wire:model="address" style="min-height:60px"></textarea></div>
        <div class="form-grid">
          <div class="field"><label>NPWP</label><input type="text" wire:model="npwp"></div>
          <div class="field"><label>Ambang Proyek Macet <span class="hint">hari tanpa update</span></label>
            <input type="number" wire:model="stuck_threshold_days" min="1" max="90">
            @error('stuck_threshold_days') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
        </div>
        <div class="field"><label>Info Rekening <span class="hint">tampil di invoice</span></label>
          <textarea wire:model="bank_info" style="min-height:60px" placeholder="Bank BCA 1234567890 a.n. PT …"></textarea></div>
        <div class="form-grid">
          <div class="field"><label>Format No. SPH <span class="hint">{urut} {romawi} {tahun}</span></label>
            <input type="text" wire:model="sph_format"></div>
          <div class="field"><label>Format No. Invoice</label>
            <input type="text" wire:model="invoice_format"></div>
        </div>
        <div class="field">
          <label>Logo <span class="hint">PNG/JPG maks 5 MB</span></label>
          @if ($settings->logo_path)
            <p class="mt-2"><img class="logo-preview" src="{{ asset('storage/' . $settings->logo_path) }}" alt="Logo perusahaan"></p>
          @endif
          <input type="file" wire:model="logo" accept="image/png,image/jpeg">
          @error('logo') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          <div wire:loading wire:target="logo" class="small muted">Mengunggah…</div>
        </div>
        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">Simpan Pengaturan</button>
      </form>
    </div>
  </div>
</div>
