@php use App\Services\ProjectStateService as P; @endphp
<div>
  <div class="page-head">
    <div><h1>Semua Proyek</h1><div class="sub">{{ $projects->count() }} proyek ditampilkan</div></div>
    <a class="btn btn-primary" href="{{ route('projects.create') }}" wire:navigate>+ Proyek Baru</a>
  </div>

  <div class="card">
    <div class="card-body">
      <div class="filters">
        <div class="field"><label>Cari</label>
          <input type="text" wire:model.live.debounce.400ms="search" placeholder="Nama proyek / klien"></div>
        <div class="field"><label>Status</label>
          <select wire:model.live="status">
            <option value="">Semua</option>
            @foreach ($statuses as $key => $label)
              <option value="{{ $key }}">{{ $label }}</option>
            @endforeach
            <option value="{{ P::CANCELLED }}">Dibatalkan</option>
          </select>
        </div>
        <div class="field"><label>Klien</label>
          <select wire:model.live="client">
            <option value="0">Semua</option>
            @foreach ($clients as $c)
              <option value="{{ $c->id }}">{{ $c->name }}</option>
            @endforeach
          </select>
        </div>
        <div class="field"><label>Dibuat dari</label><input type="date" wire:model.live="d1"></div>
        <div class="field"><label>Sampai</label><input type="date" wire:model.live="d2"></div>
        <button class="btn btn-outline" wire:click="resetFilters">Reset</button>
      </div>
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-body tight table-scroll" wire:loading.class="muted">
      <table class="table">
        <thead><tr><th>Proyek</th><th>Klien</th><th>Pipeline</th><th>Status</th><th class="right">Nilai</th><th>Dibuat</th><th>Update</th></tr></thead>
        <tbody>
        @forelse ($projects as $p)
          <tr wire:key="proj-{{ $p->id }}">
            <td>
              <a href="{{ route('projects.show', $p) }}" wire:navigate><b>{{ $p->name }}</b></a>
              @if ($p->pending_open > 0)<span class="badge b-amber">⚠ {{ $p->pending_open }} menyusul</span>@endif
            </td>
            <td>{{ $p->client->name }}<div class="small muted">{{ $p->client->company }}</div></td>
            <td><x-stepper :status="$p->status" /></td>
            <td><x-status-badge :status="$p->status" /></td>
            <td class="right">@rupiah($p->value_total)</td>
            <td class="small muted">@tgl($p->created_at)</td>
            <td class="small muted">@tgl($p->updated_at)</td>
          </tr>
        @empty
          <tr><td colspan="7" class="muted" style="padding:20px">Tidak ada proyek pada filter ini.</td></tr>
        @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>
