<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Masuk – MONIKA</title>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/style.css') }}">
</head>
<body>
<div class="login-wrap">
  <div class="login-card">
    <div class="login-brand">
      <div class="name">MONIKA</div>
      <div class="tag">Monitoring proyek · {{ \App\Models\CompanySetting::current()->name }}</div>
      <div class="login-pipe">
        <span class="step done"></span><span class="step-link done"></span>
        <span class="step done"></span><span class="step-link done"></span>
        <span class="step now"></span><span class="step-link"></span>
        <span class="step"></span><span class="step-link"></span>
        <span class="step"></span>
      </div>
    </div>
    @error('email')
      <div class="flash err">{{ $message }}</div>
    @enderror
    <form method="POST" action="{{ route('login.attempt') }}">
      @csrf
      <div class="field">
        <label for="email">Email</label>
        <input id="email" type="email" name="email" required autofocus value="{{ old('email') }}">
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input id="password" type="password" name="password" required>
      </div>
      <label style="display:flex;align-items:center;gap:8px;font-weight:400;margin-bottom:14px">
        <input type="checkbox" name="remember" style="width:auto"> Ingat saya
      </label>
      <button class="btn btn-primary" style="width:100%;justify-content:center">Masuk</button>
      <p class="small muted mt-4" style="text-align:center">Lupa password? Hubungi admin untuk mengatur ulang.</p>
    </form>
  </div>
</div>
</body>
</html>
