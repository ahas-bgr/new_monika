<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $title ?? 'MONIKA' }} – MONIKA</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/style.css') }}">
</head>
<body>
<header class="topbar">
  <div class="topbar-inner">
    <a class="brand" href="{{ route('dashboard') }}" wire:navigate>
      <span class="brand-dot"></span>MONIKA <small>v2</small>
    </a>
    <nav class="nav">
      <a href="{{ route('dashboard') }}" wire:navigate class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">Dashboard</a>
      <a href="{{ route('projects.index') }}" wire:navigate class="{{ request()->routeIs('projects.*') ? 'active' : '' }}">Proyek</a>
      <a href="{{ route('clients.index') }}" wire:navigate class="{{ request()->routeIs('clients.*') ? 'active' : '' }}">Klien</a>
      @if (auth()->user()->isAdmin())
        <a href="{{ route('users.index') }}" wire:navigate class="{{ request()->routeIs('users.*') ? 'active' : '' }}">Pengguna</a>
        <a href="{{ route('settings') }}" wire:navigate class="{{ request()->routeIs('settings') ? 'active' : '' }}">Pengaturan</a>
      @endif
    </nav>
    <div class="topbar-user">
      <span><b>{{ auth()->user()->name }}</b> · {{ auth()->user()->isAdmin() ? 'Admin' : 'Staff' }}</span>
      <form method="POST" action="{{ route('logout') }}" style="display:inline">
        @csrf
        <button type="submit" class="btn btn-sm" style="background:none;border:none;color:#FBD07C;font-weight:600;cursor:pointer;padding:0">Keluar</button>
      </form>
    </div>
  </div>
</header>
<main class="wrap">
  @foreach (['ok', 'err', 'warn'] as $type)
    @if (session($type))
      <div class="flash {{ $type }}">{{ session($type) }}</div>
    @endif
  @endforeach

  {{ $slot }}
</main>
</body>
</html>
