<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Nilai PO (untuk mengukur realisasi harga SPH vs PO di dashboard).
        Schema::table('projects', function (Blueprint $table) {
            $table->decimal('po_value', 16, 2)->nullable()->after('value_total');
        });
        Schema::table('purchase_orders', function (Blueprint $table) {
            $table->decimal('value', 16, 2)->nullable()->after('date');
        });

        // Dokumen Tender: legalitas/sertifikat perusahaan dengan masa berlaku.
        Schema::create('tender_documents', function (Blueprint $table) {
            $table->id();
            $table->string('name', 200);
            $table->date('valid_until')->nullable();
            $table->string('issuer', 180)->nullable();
            $table->string('file_path')->nullable();
            $table->string('file_name')->nullable();
            $table->foreignId('uploaded_by')->nullable()->constrained('users');
            $table->timestamps();
        });

        // Costing Sheet: kalkulasi biaya pra-SPH (feasibility & profit review).
        Schema::create('costing_sheets', function (Blueprint $table) {
            $table->id();
            $table->string('code', 40)->unique();
            $table->string('creator', 120)->nullable();
            $table->string('project_name', 200)->nullable();
            $table->string('location', 180)->nullable();

            $table->enum('cooperation_status', ['new', 'existing', 'renewal'])->default('new');
            $table->date('deadline_sph')->nullable();
            $table->date('kick_off')->nullable();
            $table->date('finish')->nullable();

            $table->unsignedInteger('point_count')->default(1);
            $table->unsignedInteger('effective_days')->default(1);
            $table->unsignedInteger('manpower_count')->default(1);
            $table->string('manpower_position', 180)->nullable();

            $table->enum('project_type', ['jasa', 'barang', 'jasa_barang'])->default('jasa');
            $table->enum('contract_type', ['one_shoot', 'termin', 'retainer'])->default('one_shoot');
            $table->decimal('margin_percent', 6, 2)->default(20);
            $table->decimal('ppn_percent', 6, 2)->default(11);
            $table->enum('status', ['draft', 'final', 'approved'])->default('draft');
            $table->text('notes')->nullable();
            $table->string('support_doc_path')->nullable();

            // Feasibility & Profit Review
            $table->decimal('plan_sph_price', 16, 2)->default(0);
            $table->decimal('hpp', 16, 2)->default(0);
            $table->decimal('nett_profit_rp', 16, 2)->default(0);
            $table->decimal('nett_profit_percent', 8, 2)->default(0);
            $table->decimal('dp_in', 16, 2)->default(0);
            $table->decimal('client_budget_estimate', 16, 2)->default(0);
            $table->decimal('market_price', 16, 2)->default(0);
            $table->enum('ot_level', ['rendah', 'sedang', 'tinggi'])->default('rendah');
            $table->enum('sla_assessment', ['sangat_layak', 'layak', 'dipertimbangkan', 'tidak_layak'])->default('layak');
            $table->text('invoice_mechanism')->nullable();
            $table->text('critical_profit_notes')->nullable();
            $table->text('additional_notes')->nullable();

            $table->foreignId('created_by')->nullable()->constrained('users');
            $table->timestamps();
        });

        Schema::create('costing_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('costing_sheet_id')->constrained()->cascadeOnDelete();
            $table->enum('category', ['manpower', 'material', 'transport', 'alat', 'lain'])->default('manpower');
            $table->string('description', 200)->nullable();
            $table->decimal('qty', 12, 2)->default(0);
            $table->string('unit', 30)->default('unit');
            $table->decimal('duration', 12, 2)->default(1);
            $table->decimal('unit_price', 16, 2)->default(0);
            $table->string('note', 200)->nullable();
            $table->unsignedInteger('sort_order')->default(0);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('costing_items');
        Schema::dropIfExists('costing_sheets');
        Schema::dropIfExists('tender_documents');
        Schema::table('purchase_orders', fn (Blueprint $t) => $t->dropColumn('value'));
        Schema::table('projects', fn (Blueprint $t) => $t->dropColumn('po_value'));
    }
};
