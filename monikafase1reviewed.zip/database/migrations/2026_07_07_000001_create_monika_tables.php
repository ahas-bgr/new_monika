<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Kolom tambahan pada tabel users bawaan Laravel
        Schema::table('users', function (Blueprint $table) {
            $table->enum('role', ['admin', 'staff'])->default('staff')->after('password');
            $table->boolean('is_active')->default(true)->after('role');
        });

        Schema::create('company_settings', function (Blueprint $table) {
            $table->tinyInteger('id')->unsigned()->primary();
            $table->string('name', 180);
            $table->string('logo_path')->nullable();
            $table->text('address')->nullable();
            $table->string('city', 80)->default('Bogor');
            $table->string('npwp', 40)->nullable();
            $table->text('bank_info')->nullable();
            $table->string('director_name', 120)->nullable();
            // Penomoran dokumen. Placeholder: {urut} (nomor urut, boleh 0-padding
            // mis. 00010 lewat {urut:5}), {romawi} (bulan angka Romawi), {tahun}.
            $table->string('sph_format', 80)->default('{urut}/DK/SPH/{romawi}/{tahun}');
            $table->string('invoice_format', 80)->default('{urut}/INV/DK/{romawi}/{tahun}');
            $table->string('kwitansi_format', 80)->default('{urut}/KW/DK/{romawi}/{tahun}');
            $table->unsignedSmallInteger('stuck_threshold_days')->default(7);
        });

        Schema::create('clients', function (Blueprint $table) {
            $table->id();
            $table->string('name', 120);
            $table->string('company', 180)->nullable();
            $table->text('address')->nullable();
            $table->string('email', 160)->nullable();
            $table->string('phone', 40)->nullable();
            $table->timestamps();
        });

        Schema::create('projects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('client_id')->constrained();
            $table->string('name', 180);
            $table->text('description')->nullable();
            $table->string('status', 30)->default('sph_draft')->index();
            $table->decimal('value_total', 16, 2)->default(0);
            $table->text('cancelled_reason')->nullable();
            $table->foreignId('created_by')->nullable()->constrained('users');
            $table->timestamps();
            $table->softDeletes();
        });

        Schema::create('project_status_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('from_status', 30)->nullable();
            $table->string('to_status', 30);
            $table->foreignId('user_id')->nullable()->constrained();
            $table->text('note')->nullable();
            $table->boolean('is_override')->default(false);
            $table->json('skipped_requirements')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });

        Schema::create('pending_requirements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('type', 40);
            $table->enum('status', ['open', 'resolved'])->default('open');
            $table->foreignId('created_by')->nullable()->constrained('users');
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('resolved_at')->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users');
            $table->text('resolve_note')->nullable();
            $table->index(['project_id', 'status']);
        });

        Schema::create('quotations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->foreignId('parent_quotation_id')->nullable()->constrained('quotations');
            $table->unsignedSmallInteger('revision_number')->default(0);
            $table->string('number', 80);
            $table->date('date');
            $table->date('valid_until')->nullable();
            $table->decimal('ppn_percent', 5, 2)->default(0);
            $table->enum('status', ['draft', 'terkirim', 'po_diterima', 'superseded', 'kedaluwarsa'])->default('draft');
            $table->timestamp('sent_at')->nullable();
            $table->timestamps();
        });

        Schema::create('quotation_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('quotation_id')->constrained()->cascadeOnDelete();
            $table->string('description');
            $table->decimal('qty', 10, 2)->default(1);
            $table->string('unit', 30)->default('unit');
            $table->decimal('unit_price', 16, 2)->default(0);
        });

        Schema::create('purchase_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('number', 80);
            $table->date('date');
            $table->string('file_path')->nullable();
            $table->timestamps();
        });

        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('title', 200);
            $table->text('description')->nullable();
            $table->foreignId('assignee_id')->nullable()->constrained('users');
            $table->date('deadline')->nullable();
            $table->enum('status', ['todo', 'in_progress', 'done'])->default('todo');
            $table->timestamps();
        });

        // Catatan: BAST TIDAK dikelola MONIKA — digenerate aplikasi tim Operation
        // (penanggung jawab berbeda). Nomor BAST eksternal cukup direferensikan
        // di invoice (kolom bast_ref) saat modul invoice dibuat (Fase 3).

        Schema::create('invoices', function (Blueprint $table) {
            $table->id();
            $table->foreignId('project_id')->constrained()->cascadeOnDelete();
            $table->string('number', 80);
            $table->enum('invoice_type', ['dp', 'progress', 'pelunasan', 'full'])->default('full');
            $table->date('date');
            $table->date('due_date')->nullable();
            $table->decimal('total', 16, 2)->default(0);
            $table->enum('status', ['belum', 'sebagian', 'lunas'])->default('belum');
            $table->timestamp('sent_at')->nullable();
            $table->timestamps();
        });

        Schema::create('invoice_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->string('description');
            $table->decimal('qty', 10, 2)->default(1);
            $table->string('unit', 30)->default('unit');
            $table->decimal('unit_price', 16, 2)->default(0);
        });

        Schema::create('payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('invoice_id')->constrained()->cascadeOnDelete();
            $table->date('date');
            $table->decimal('amount', 16, 2);
            $table->string('method', 60)->nullable();
            $table->string('proof_file_path')->nullable();
            $table->foreignId('recorded_by')->nullable()->constrained('users');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
        Schema::dropIfExists('invoice_items');
        Schema::dropIfExists('invoices');
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('purchase_orders');
        Schema::dropIfExists('quotation_items');
        Schema::dropIfExists('quotations');
        Schema::dropIfExists('pending_requirements');
        Schema::dropIfExists('project_status_logs');
        Schema::dropIfExists('projects');
        Schema::dropIfExists('clients');
        Schema::dropIfExists('company_settings');
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn(['role', 'is_active']);
        });
    }
};
