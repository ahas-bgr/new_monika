<?php

namespace App\Support;

use Illuminate\Database\Eloquent\Builder;

/**
 * Definisi 9 kotak status dashboard MONIKA (SPH vs PO).
 *
 * Istilah:
 *  - "PO Belum / Sudah" = PO dari customer belum / sudah diterima.
 *  - "Work Progress"    = pekerjaan sudah mulai, belum 100% (status pengerjaan).
 *  - "Work Done"        = pekerjaan selesai 100% + BAST terbit (tim Operation);
 *                         di alur MONIKA = tahap invoicing / menunggu_pembayaran.
 */
class ProjectBucket
{
    /** status pekerjaan sedang berjalan */
    public const IN_PROGRESS = ['pengerjaan'];

    /** status pekerjaan selesai (BAST eksternal terbit), masih ditagih */
    public const WORK_DONE = ['invoicing', 'menunggu_pembayaran'];

    /** status masih perencanaan / penawaran */
    public const ON_PLAN = ['sph_draft', 'menunggu_po'];

    /** @return array<string, array{label:string, color:string, hint:string}> */
    public static function all(): array
    {
        return [
            'total' => ['label' => 'Total Project', 'color' => 'navy',
                'hint' => 'Semua project (SPH yang dibuat)'],
            'accepted' => ['label' => 'Total Project Accepted', 'color' => 'purple',
                'hint' => 'Sudah terbit PO atau dieksekusi tanpa PO'],
            'done' => ['label' => 'Total Done', 'color' => 'green',
                'hint' => 'Project selesai (lunas)'],
            'invoice_uncomplete' => ['label' => 'Invoice Uncomplete', 'color' => 'blue',
                'hint' => 'Pekerjaan selesai, tagihan belum lunas'],
            'po_belum_work_done' => ['label' => 'PO Belum, Work Done', 'color' => 'amber',
                'hint' => 'Dikerjakan sampai selesai tanpa PO (PO menyusul)'],
            'po_belum_work_progress' => ['label' => 'PO Belum, Work Progress', 'color' => 'orange',
                'hint' => 'Dikerjakan tanpa PO, masih berjalan'],
            'po_sudah_work_progress' => ['label' => 'PO Sudah, Work Progress', 'color' => 'brown',
                'hint' => 'PO diterima, pekerjaan sedang berjalan'],
            'on_plan' => ['label' => 'On Plan', 'color' => 'slate',
                'hint' => 'Masih tahap SPH / penawaran, belum PO'],
            'take_out' => ['label' => 'Take Out', 'color' => 'red',
                'hint' => 'Project dibatalkan / batal tender'],
        ];
    }

    public static function label(string $bucket): string
    {
        return self::all()[$bucket]['label'] ?? $bucket;
    }

    public static function exists(string $bucket): bool
    {
        return isset(self::all()[$bucket]);
    }

    /** Terapkan filter satu bucket ke query Project. */
    public static function apply(Builder $q, string $bucket): Builder
    {
        return match ($bucket) {
            'total' => $q,

            'accepted' => $q->where(fn ($w) => $w
                ->whereHas('purchaseOrders')
                ->orWhereIn('status', [...self::IN_PROGRESS, ...self::WORK_DONE, 'selesai'])),

            'done' => $q->where('status', 'selesai'),

            'invoice_uncomplete' => $q->whereIn('status', self::WORK_DONE)
                ->where(fn ($w) => $w->whereDoesntHave('invoices')
                    ->orWhereHas('invoices', fn ($i) => $i->where('status', '!=', 'lunas'))),

            'po_belum_work_done' => $q->whereDoesntHave('purchaseOrders')
                ->whereIn('status', self::WORK_DONE),

            'po_belum_work_progress' => $q->whereDoesntHave('purchaseOrders')
                ->whereIn('status', self::IN_PROGRESS),

            'po_sudah_work_progress' => $q->whereHas('purchaseOrders')
                ->whereIn('status', self::IN_PROGRESS),

            'on_plan' => $q->whereIn('status', self::ON_PLAN),

            'take_out' => $q->where('status', 'dibatalkan'),

            default => $q,
        };
    }

    /**
     * Statistik satu bucket: jumlah project + nominal SPH + nominal PO.
     *
     * @return array{count:int, sph_count:int, sph_sum:float, po_count:int, po_sum:float}
     */
    public static function stats(string $bucket): array
    {
        $base = self::apply(\App\Models\Project::query(), $bucket);

        $sph = (clone $base)->selectRaw('COUNT(*) c, COALESCE(SUM(value_total),0) s')
            ->where('value_total', '>', 0)->first();
        $po = (clone $base)->selectRaw('COUNT(*) c, COALESCE(SUM(po_value),0) s')
            ->whereNotNull('po_value')->first();

        return [
            'count'     => (clone $base)->count(),
            'sph_count' => (int) $sph->c,
            'sph_sum'   => (float) $sph->s,
            'po_count'  => (int) $po->c,
            'po_sum'    => (float) $po->s,
        ];
    }
}
