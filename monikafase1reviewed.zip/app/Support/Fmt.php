<?php

namespace App\Support;

use Carbon\CarbonInterface;

class Fmt
{
    public static function rupiah($n): string
    {
        return 'Rp ' . number_format((float) $n, 0, ',', '.');
    }

    public static function tgl(null|string|CarbonInterface $date, bool $withTime = false): string
    {
        if (! $date) {
            return '–';
        }
        $c = $date instanceof CarbonInterface ? $date : \Carbon\Carbon::parse($date);

        return $c->locale('id')->translatedFormat($withTime ? 'j F Y H:i' : 'j F Y');
    }

    public static function umurHari(null|string|CarbonInterface $date): int
    {
        if (! $date) {
            return 0;
        }
        $c = $date instanceof CarbonInterface ? $date : \Carbon\Carbon::parse($date);

        return (int) $c->diffInDays(now());
    }
}
