<?php

namespace App\Livewire\Projects;

use App\Models\Client;
use App\Models\Project;
use App\Models\ProjectStatusLog;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Form Proyek')]
class Form extends Component
{
    public ?Project $project = null;

    public string $name = '';
    public ?int $client_id = null;
    public string $value_total = '';
    public string $description = '';

    public function mount(?Project $project = null): void
    {
        if ($project && $project->exists) {
            $this->project     = $project;
            $this->name        = $project->name;
            $this->client_id   = $project->client_id;
            $this->value_total = number_format((float) $project->value_total, 0, ',', '.');
            $this->description = (string) $project->description;
        }
    }

    public function save()
    {
        $validated = $this->validate([
            'name'        => ['required', 'string', 'max:180'],
            'client_id'   => ['required', 'exists:clients,id'],
            'value_total' => ['nullable', 'string'],
            'description' => ['nullable', 'string'],
        ], [], [
            'name'      => 'nama proyek',
            'client_id' => 'klien',
        ]);

        $value = (float) str_replace(['.', ','], ['', '.'], $this->value_total ?: '0');

        if ($this->project) {
            $this->project->update([
                'name'        => $validated['name'],
                'client_id'   => $validated['client_id'],
                'value_total' => $value,
                'description' => $validated['description'] ?? null,
            ]);
            session()->flash('ok', 'Proyek diperbarui.');

            return $this->redirectRoute('projects.show', $this->project);
        }

        $project = Project::create([
            'name'        => $validated['name'],
            'client_id'   => $validated['client_id'],
            'value_total' => $value,
            'description' => $validated['description'] ?? null,
            'status'      => 'sph_draft',
            'created_by'  => auth()->id(),
        ]);

        ProjectStatusLog::create([
            'project_id' => $project->id,
            'to_status'  => 'sph_draft',
            'user_id'    => auth()->id(),
            'note'       => 'Proyek dibuat',
        ]);

        session()->flash('ok', 'Proyek baru dibuat. Tahap awal: SPH Draft.');

        return $this->redirectRoute('projects.show', $project);
    }

    public function render()
    {
        return view('livewire.projects.form', [
            'clients' => Client::orderBy('name')->get(['id', 'name', 'company']),
        ]);
    }
}
