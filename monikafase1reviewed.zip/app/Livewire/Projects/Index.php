<?php

namespace App\Livewire\Projects;

use App\Models\Client;
use App\Models\Project;
use App\Services\ProjectStateService;
use App\Support\Fmt;
use App\Support\ProjectBucket;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Component;

#[Title('Proyek')]
class Index extends Component
{
    #[Url(as: 'q')]
    public string $search = '';

    #[Url]
    public string $status = '';

    #[Url]
    public int $client = 0;

    #[Url]
    public string $d1 = '';

    #[Url]
    public string $d2 = '';

    /** Kotak status dashboard (App\Support\ProjectBucket). */
    #[Url]
    public string $bucket = '';

    public function resetFilters(): void
    {
        $this->reset(['search', 'status', 'client', 'd1', 'd2', 'bucket']);
    }

    public function clearBucket(): void
    {
        $this->bucket = '';
    }

    protected function baseQuery(): Builder
    {
        return Project::query()
            ->when($this->bucket !== '' && ProjectBucket::exists($this->bucket),
                fn ($q) => ProjectBucket::apply($q, $this->bucket))
            ->when($this->search !== '', function ($q) {
                $q->where(function ($w) {
                    $w->where('name', 'like', "%{$this->search}%")
                        ->orWhereHas('client', fn ($c) => $c
                            ->where('name', 'like', "%{$this->search}%")
                            ->orWhere('company', 'like', "%{$this->search}%"));
                });
            })
            ->when($this->status !== '', fn ($q) => $q->where('status', $this->status))
            ->when($this->client > 0, fn ($q) => $q->where('client_id', $this->client))
            ->when($this->d1 !== '', fn ($q) => $q->whereDate('created_at', '>=', $this->d1))
            ->when($this->d2 !== '', fn ($q) => $q->whereDate('created_at', '<=', $this->d2));
    }

    /** Unduh hasil filter saat ini sebagai file (CSV, terbaca Excel). */
    public function export()
    {
        $rows = $this->baseQuery()->with('client:id,name,company')->latest('updated_at')->get();
        $name = 'projek-' . ($this->bucket ?: 'semua') . '-' . now()->format('Ymd-Hi') . '.csv';

        return response()->streamDownload(function () use ($rows) {
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF"); // BOM agar Excel membaca UTF-8
            fputcsv($out, ['Nama Proyek', 'Klien', 'Perusahaan', 'Status', 'Nilai SPH', 'Nilai PO', 'Dibuat', 'Update Terakhir']);
            foreach ($rows as $p) {
                fputcsv($out, [
                    $p->name,
                    $p->client?->name,
                    $p->client?->company,
                    ProjectStateService::label($p->status),
                    (float) $p->value_total,
                    $p->po_value !== null ? (float) $p->po_value : '',
                    Fmt::tgl($p->created_at),
                    Fmt::tgl($p->updated_at),
                ]);
            }
            fclose($out);
        }, $name, ['Content-Type' => 'text/csv; charset=UTF-8']);
    }

    public function render()
    {
        $projects = $this->baseQuery()
            ->with('client:id,name,company')
            ->withCount(['openRequirements as pending_open'])
            ->latest('updated_at')
            ->limit(300)
            ->get();

        return view('livewire.projects.index', [
            'projects'    => $projects,
            'clients'     => Client::orderBy('name')->get(['id', 'name']),
            'statuses'    => ProjectStateService::STATUSES,
            'bucketLabel' => ($this->bucket !== '' && ProjectBucket::exists($this->bucket))
                ? ProjectBucket::label($this->bucket) : null,
        ]);
    }
}
