<?php

namespace App\Livewire\Projects;

use App\Models\Project;
use App\Models\Task;
use App\Services\ProjectStateService;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Detail Proyek')]
class Detail extends Component
{
    public Project $project;

    // Form-form aksi
    public string $overrideNote = '';
    public string $rollbackNote = '';
    public string $cancelNote = '';
    public string $newTaskTitle = '';
    public string $newTaskDeadline = '';

    /** @var array<int, string> catatan pelengkapan per requirement */
    public array $resolveNotes = [];

    public function mount(Project $project): void
    {
        $this->project = $project;
    }

    protected function service(): ProjectStateService
    {
        return app(ProjectStateService::class);
    }

    protected function flashResult(array $result): void
    {
        [$ok, $msg] = $result;
        session()->flash($ok ? 'ok' : 'err', $msg);
        $this->project->refresh();
    }

    /* ---------------- Aksi state machine ---------------- */

    public function advance(): void
    {
        $this->flashResult(
            $this->service()->advance($this->project, auth()->user())
        );
    }

    public function override(): void
    {
        $this->flashResult(
            $this->service()->advance($this->project, auth()->user(), true, $this->overrideNote)
        );
        $this->overrideNote = '';
    }

    public function rollback(): void
    {
        $this->flashResult(
            $this->service()->rollback($this->project, auth()->user(), $this->rollbackNote)
        );
        $this->rollbackNote = '';
    }

    public function cancelProject(): void
    {
        $this->flashResult(
            $this->service()->cancel($this->project, auth()->user(), $this->cancelNote)
        );
        $this->cancelNote = '';
    }

    public function resolveRequirement(int $requirementId): void
    {
        abort_unless(auth()->user()->isAdmin(), 403);

        $note = trim($this->resolveNotes[$requirementId] ?? '');
        $this->flashResult(
            $this->service()->resolveRequirement($requirementId, auth()->user(), $note)
        );
        unset($this->resolveNotes[$requirementId]);
    }

    /* ---------------- Task ---------------- */

    public function addTask(): void
    {
        $this->validate(
            ['newTaskTitle' => ['required', 'string', 'max:200']],
            [],
            ['newTaskTitle' => 'judul task'],
        );

        Task::create([
            'project_id'  => $this->project->id,
            'title'       => $this->newTaskTitle,
            'deadline'    => $this->newTaskDeadline ?: null,
            'status'      => 'todo',
            'assignee_id' => auth()->id(),
        ]);

        $this->project->touch();
        $this->reset(['newTaskTitle', 'newTaskDeadline']);
        session()->flash('ok', 'Task ditambahkan.');
        $this->project->refresh();
    }

    public function toggleTask(int $taskId): void
    {
        $task = Task::where('project_id', $this->project->id)->findOrFail($taskId);
        $task->update(['status' => $task->status === 'done' ? 'todo' : 'done']);
        $this->project->touch();
        $this->project->refresh();
    }

    /* ---------------- Render ---------------- */

    public function render()
    {
        $service = $this->service();

        $this->project->load([
            'client',
            'tasks' => fn ($q) => $q->orderByRaw("status = 'done'")
                ->orderByRaw('deadline IS NULL')->orderBy('deadline'),
            'openRequirements',
            'statusLogs.user',
        ]);

        $isFinal = in_array($this->project->status, ['selesai', ProjectStateService::CANCELLED], true);

        return view('livewire.projects.detail', [
            'unmet'      => $isFinal ? [] : $service->unmetRequirements($this->project),
            'nextStatus' => ProjectStateService::next($this->project->status),
            'prevStatus' => ProjectStateService::prev($this->project->status),
            'isFinal'    => $isFinal,
            'reqLabels'  => ProjectStateService::REQ_LABELS,
            'progress'   => $this->project->taskProgress(),
        ]);
    }
}
