<?php

namespace App\Livewire\Admin;

use App\Models\CompanySetting;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Title('Pengaturan')]
class CompanySettings extends Component
{
    use WithFileUploads;

    public string $name = '';
    public string $address = '';
    public string $city = '';
    public string $npwp = '';
    public string $bank_info = '';
    public string $director_name = '';
    public string $sph_format = '';
    public string $invoice_format = '';
    public string $kwitansi_format = '';
    public int $stuck_threshold_days = 7;

    public $logo = null;

    public function mount(): void
    {
        abort_unless(auth()->user()?->isAdmin(), 403);

        $s = CompanySetting::current();
        $this->name                 = (string) $s->name;
        $this->address              = (string) $s->address;
        $this->city                 = (string) $s->city;
        $this->npwp                 = (string) $s->npwp;
        $this->bank_info            = (string) $s->bank_info;
        $this->director_name        = (string) $s->director_name;
        $this->sph_format           = (string) $s->sph_format;
        $this->invoice_format       = (string) $s->invoice_format;
        $this->kwitansi_format      = (string) $s->kwitansi_format;
        $this->stuck_threshold_days = (int) $s->stuck_threshold_days;
    }

    public function save(): void
    {
        $this->validate([
            'name'                 => ['required', 'string', 'max:180'],
            'address'              => ['nullable', 'string'],
            'city'                 => ['nullable', 'string', 'max:80'],
            'npwp'                 => ['nullable', 'string', 'max:40'],
            'bank_info'            => ['nullable', 'string'],
            'director_name'        => ['nullable', 'string', 'max:120'],
            'sph_format'           => ['required', 'string', 'max:80'],
            'invoice_format'       => ['required', 'string', 'max:80'],
            'kwitansi_format'      => ['required', 'string', 'max:80'],
            'stuck_threshold_days' => ['required', 'integer', 'min:1', 'max:90'],
            'logo'                 => ['nullable', 'image', 'mimes:png,jpg,jpeg', 'max:5120'],
        ], [], ['name' => 'nama perusahaan']);

        $s = CompanySetting::current();

        $logoPath = $s->logo_path;
        if ($this->logo) {
            $logoPath = $this->logo->store('logo', 'public');
        }

        $s->update([
            'name'                 => $this->name,
            'address'              => $this->address,
            'city'                 => $this->city,
            'npwp'                 => $this->npwp,
            'bank_info'            => $this->bank_info,
            'director_name'        => $this->director_name,
            'sph_format'           => $this->sph_format,
            'invoice_format'       => $this->invoice_format,
            'kwitansi_format'      => $this->kwitansi_format,
            'stuck_threshold_days' => $this->stuck_threshold_days,
            'logo_path'            => $logoPath,
        ]);

        $this->logo = null;
        session()->flash('ok', 'Pengaturan disimpan.');
    }

    public function render()
    {
        return view('livewire.admin.company-settings', [
            'settings' => CompanySetting::current(),
        ]);
    }
}
