<?php

namespace App\Livewire\Costing;

use App\Models\CostingSheet;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Costing Sheet')]
class Index extends Component
{
    public function delete(int $id): void
    {
        $sheet = CostingSheet::findOrFail($id);
        if ($sheet->support_doc_path) {
            Storage::disk('public')->delete($sheet->support_doc_path);
        }
        $sheet->delete();
        session()->flash('ok', 'Costing Sheet dihapus.');
    }

    public function render()
    {
        return view('livewire.costing.index', [
            'sheets' => CostingSheet::withCount('items')->latest()->get(),
        ]);
    }
}
