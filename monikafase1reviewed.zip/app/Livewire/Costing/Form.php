<?php

namespace App\Livewire\Costing;

use App\Models\CostingItem;
use App\Models\CostingSheet;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Title('Costing Sheet')]
class Form extends Component
{
    use WithFileUploads;

    public ?int $sheetId = null;
    public string $code = '';

    // Informasi Project
    public string $creator = '';
    public string $project_name = '';
    public string $location = '';
    public string $cooperation_status = 'new';
    public ?string $deadline_sph = null;
    public ?string $kick_off = null;
    public ?string $finish = null;
    public int $point_count = 1;
    public int $effective_days = 1;
    public int $manpower_count = 1;
    public string $manpower_position = '';
    public string $project_type = 'jasa';
    public string $contract_type = 'one_shoot';
    public float $margin_percent = 20;
    public float $ppn_percent = 11;
    public string $status = 'draft';
    public string $notes = '';
    public $support_doc = null;
    public ?string $support_doc_path = null;

    // Feasibility & Profit Review
    public float $plan_sph_price = 0;
    public float $dp_in = 0;
    public float $client_budget_estimate = 0;
    public float $market_price = 0;
    public string $ot_level = 'rendah';
    public string $sla_assessment = 'layak';
    public string $invoice_mechanism = '';
    public string $critical_profit_notes = '';
    public string $additional_notes = '';

    /** @var array<int, array<string, mixed>> */
    public array $items = [];

    /** penghitung untuk wire:key stabil tiap baris item */
    public int $itemSeq = 0;

    public function mount(?CostingSheet $costing = null): void
    {
        if ($costing && $costing->exists) {
            $this->sheetId = $costing->id;
            $this->fill($costing->only([
                'code', 'creator', 'project_name', 'location', 'cooperation_status',
                'point_count', 'effective_days', 'manpower_count', 'manpower_position',
                'project_type', 'contract_type', 'margin_percent', 'ppn_percent', 'status',
                'notes', 'support_doc_path', 'plan_sph_price', 'dp_in', 'client_budget_estimate',
                'market_price', 'ot_level', 'sla_assessment', 'invoice_mechanism',
                'critical_profit_notes', 'additional_notes',
            ]));
            $this->deadline_sph = $costing->deadline_sph?->format('Y-m-d');
            $this->kick_off = $costing->kick_off?->format('Y-m-d');
            $this->finish = $costing->finish?->format('Y-m-d');
            foreach ($costing->items as $i) {
                $this->items[++$this->itemSeq] = [
                    'category' => $i->category, 'description' => $i->description,
                    'qty' => (float) $i->qty, 'unit' => $i->unit, 'duration' => (float) $i->duration,
                    'unit_price' => (float) $i->unit_price, 'note' => (string) $i->note,
                ];
            }

            return;
        }

        $this->code = CostingSheet::nextCode();
        $this->creator = (string) auth()->user()->name;
        // Baris manpower default (Gambar 3)
        foreach (['Supervisor', 'Teknisi Senior', 'Teknisi Junior', 'Helper', 'Admin Project'] as $pos) {
            $this->items[++$this->itemSeq] = $this->blankItem('manpower', $pos, 'orang');
        }
    }

    protected function blankItem(string $cat = 'manpower', string $desc = '', string $unit = 'unit'): array
    {
        return ['category' => $cat, 'description' => $desc,
            'qty' => 0, 'unit' => $unit, 'duration' => 1, 'unit_price' => 0, 'note' => ''];
    }

    public function addItem(): void
    {
        // Kunci array = _key stabil; path wire:model tak bergeser saat baris dihapus.
        $this->items[++$this->itemSeq] = $this->blankItem('material', '', 'unit');
    }

    public function removeItem($key): void
    {
        unset($this->items[$key]);
    }

    /* -------- Perhitungan hidup -------- */

    public function itemTotal(array $it): float
    {
        return (float) ($it['qty'] ?? 0) * (float) ($it['duration'] ?? 0) * (float) ($it['unit_price'] ?? 0);
    }

    public function getSubtotalHppProperty(): float
    {
        return array_reduce($this->items, fn ($c, $it) => $c + $this->itemTotal($it), 0.0);
    }

    public function getMarginRpProperty(): float
    {
        return $this->subtotalHpp * ((float) $this->margin_percent) / 100;
    }

    public function getDppProperty(): float
    {
        return $this->subtotalHpp + $this->marginRp;
    }

    public function getPpnRpProperty(): float
    {
        return $this->dpp * ((float) $this->ppn_percent) / 100;
    }

    public function getGrandTotalProperty(): float
    {
        return $this->dpp + $this->ppnRp;
    }

    public function getNettProfitRpProperty(): float
    {
        return (float) $this->plan_sph_price - $this->subtotalHpp;
    }

    public function getNettProfitPercentProperty(): float
    {
        return $this->plan_sph_price > 0 ? $this->nettProfitRp / (float) $this->plan_sph_price * 100 : 0;
    }

    public function save(): void
    {
        $data = $this->validate([
            'project_name'      => ['required', 'string', 'max:200'],
            'creator'           => ['nullable', 'string', 'max:120'],
            'location'          => ['nullable', 'string', 'max:180'],
            'cooperation_status' => ['required', 'in:new,existing,renewal'],
            'deadline_sph'      => ['nullable', 'date'],
            'kick_off'          => ['nullable', 'date'],
            'finish'            => ['nullable', 'date'],
            'point_count'       => ['required', 'integer', 'min:0'],
            'effective_days'    => ['required', 'integer', 'min:0'],
            'manpower_count'    => ['required', 'integer', 'min:0'],
            'manpower_position' => ['nullable', 'string', 'max:180'],
            'project_type'      => ['required', 'in:jasa,barang,jasa_barang'],
            'contract_type'     => ['required', 'in:one_shoot,termin,retainer'],
            'margin_percent'    => ['required', 'numeric', 'min:0', 'max:1000'],
            'ppn_percent'       => ['required', 'numeric', 'min:0', 'max:100'],
            'status'            => ['required', 'in:draft,final,approved'],
            'plan_sph_price'    => ['numeric', 'min:0'],
            'dp_in'             => ['numeric', 'min:0'],
            'client_budget_estimate' => ['numeric', 'min:0'],
            'market_price'      => ['numeric', 'min:0'],
            'ot_level'          => ['required', 'in:rendah,sedang,tinggi'],
            'sla_assessment'    => ['required', 'in:sangat_layak,layak,dipertimbangkan,tidak_layak'],
            'support_doc'       => ['nullable', 'file', 'max:10240'],
        ], [], ['project_name' => 'nama project']);

        $payload = [
            'creator' => $this->creator ?: null,
            'project_name' => $this->project_name,
            'location' => $this->location ?: null,
            'cooperation_status' => $this->cooperation_status,
            'deadline_sph' => $this->deadline_sph ?: null,
            'kick_off' => $this->kick_off ?: null,
            'finish' => $this->finish ?: null,
            'point_count' => $this->point_count,
            'effective_days' => $this->effective_days,
            'manpower_count' => $this->manpower_count,
            'manpower_position' => $this->manpower_position ?: null,
            'project_type' => $this->project_type,
            'contract_type' => $this->contract_type,
            'margin_percent' => $this->margin_percent,
            'ppn_percent' => $this->ppn_percent,
            'status' => $this->status,
            'notes' => $this->notes ?: null,
            'plan_sph_price' => $this->plan_sph_price,
            'hpp' => $this->subtotalHpp,
            'nett_profit_rp' => $this->nettProfitRp,
            'nett_profit_percent' => $this->nettProfitPercent,
            'dp_in' => $this->dp_in,
            'client_budget_estimate' => $this->client_budget_estimate,
            'market_price' => $this->market_price,
            'ot_level' => $this->ot_level,
            'sla_assessment' => $this->sla_assessment,
            'invoice_mechanism' => $this->invoice_mechanism ?: null,
            'critical_profit_notes' => $this->critical_profit_notes ?: null,
            'additional_notes' => $this->additional_notes ?: null,
        ];

        if ($this->support_doc) {
            $payload['support_doc_path'] = $this->support_doc->store('costing', 'public');
        }

        DB::transaction(function () use ($payload) {
            if ($this->sheetId) {
                $sheet = CostingSheet::findOrFail($this->sheetId);
                $sheet->update($payload);
                $sheet->items()->delete();
            } else {
                $payload['code'] = $this->code;
                $payload['created_by'] = auth()->id();
                $sheet = CostingSheet::create($payload);
                $this->sheetId = $sheet->id;
            }

            $order = 0;
            foreach ($this->items as $it) {
                // Aturan: MANPOWER dengan Qty 0 tidak disimpan.
                if (($it['category'] ?? '') === 'manpower' && (float) ($it['qty'] ?? 0) === 0.0) {
                    continue;
                }
                if (($it['description'] ?? '') === '' && (float) ($it['unit_price'] ?? 0) === 0.0) {
                    continue;
                }
                CostingItem::create([
                    'costing_sheet_id' => $sheet->id,
                    'category' => $it['category'] ?? 'lain',
                    'description' => $it['description'] ?? '',
                    'qty' => (float) ($it['qty'] ?? 0),
                    'unit' => $it['unit'] ?? 'unit',
                    'duration' => (float) ($it['duration'] ?? 1),
                    'unit_price' => (float) ($it['unit_price'] ?? 0),
                    'note' => $it['note'] ?? null,
                    'sort_order' => $order++,
                ]);
            }
        });

        session()->flash('ok', 'Costing Sheet ' . $this->code . ' tersimpan.');
        $this->redirectRoute('costing.index', navigate: true);
    }

    public function render()
    {
        return view('livewire.costing.form', [
            'categories' => CostingItem::CATEGORIES,
        ]);
    }
}
