<?php

namespace App\Livewire;

use App\Models\Client;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Title('Klien')]
class Clients extends Component
{
    public ?int $editId = null;

    public string $name = '';
    public string $company = '';
    public string $email = '';
    public string $phone = '';
    public string $address = '';

    public function edit(int $id): void
    {
        $c = Client::findOrFail($id);
        $this->editId  = $c->id;
        $this->name    = (string) $c->name;
        $this->company = (string) $c->company;
        $this->email   = (string) $c->email;
        $this->phone   = (string) $c->phone;
        $this->address = (string) $c->address;
    }

    public function cancelEdit(): void
    {
        $this->reset(['editId', 'name', 'company', 'email', 'phone', 'address']);
        $this->resetValidation();
    }

    public function save(): void
    {
        $data = $this->validate([
            'name'    => ['required', 'string', 'max:120'],
            'company' => ['nullable', 'string', 'max:180'],
            'email'   => ['nullable', 'email', 'max:160'],
            'phone'   => ['nullable', 'string', 'max:40'],
            'address' => ['nullable', 'string'],
        ], [], ['name' => 'nama klien']);

        if ($this->editId) {
            Client::findOrFail($this->editId)->update($data);
            session()->flash('ok', 'Data klien diperbarui.');
        } else {
            Client::create($data);
            session()->flash('ok', 'Klien baru ditambahkan.');
        }

        $this->cancelEdit();
    }

    public function render()
    {
        return view('livewire.clients', [
            'clients' => Client::withCount('projects')->orderBy('name')->get(),
        ]);
    }
}
