<?php

namespace App\Livewire;

use App\Models\TenderDocument;
use Illuminate\Support\Facades\Storage;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Title('Dokumen Tender')]
class TenderDocuments extends Component
{
    use WithFileUploads;

    public bool $showForm = false;

    public string $name = '';
    public ?string $valid_until = null;
    public string $issuer = '';
    public $file = null;

    public function openForm(): void
    {
        $this->reset(['name', 'valid_until', 'issuer', 'file']);
        $this->resetValidation();
        $this->showForm = true;
    }

    public function save(): void
    {
        $data = $this->validate([
            'name'        => ['required', 'string', 'max:200'],
            'valid_until' => ['nullable', 'date'],
            'issuer'      => ['nullable', 'string', 'max:180'],
            'file'        => ['required', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png,xls,xlsx,ppt,pptx', 'max:10240'],
        ], [], ['name' => 'nama dokumen', 'file' => 'file dokumen']);

        $stored = $this->file->store('tender', 'public');

        TenderDocument::create([
            'name'        => $data['name'],
            'valid_until' => $data['valid_until'] ?: null,
            'issuer'      => $data['issuer'] ?: null,
            'file_path'   => $stored,
            'file_name'   => $this->file->getClientOriginalName(),
            'uploaded_by' => auth()->id(),
        ]);

        $this->showForm = false;
        $this->reset(['name', 'valid_until', 'issuer', 'file']);
        session()->flash('ok', 'Dokumen tender tersimpan.');
    }

    public function delete(int $id): void
    {
        $doc = TenderDocument::findOrFail($id);
        if ($doc->file_path) {
            Storage::disk('public')->delete($doc->file_path);
        }
        $doc->delete();
        session()->flash('ok', 'Dokumen dihapus.');
    }

    public function render()
    {
        return view('livewire.tender-documents', [
            'documents' => TenderDocument::with('uploader:id,name')->latest()->get(),
        ]);
    }
}
