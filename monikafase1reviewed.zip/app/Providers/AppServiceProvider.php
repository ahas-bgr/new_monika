<?php

namespace App\Providers;

use Carbon\Carbon;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        Carbon::setLocale('id');

        Blade::directive('rupiah', fn ($expr) => "<?php echo \\App\\Support\\Fmt::rupiah($expr); ?>");
        Blade::directive('tgl', fn ($expr) => "<?php echo \\App\\Support\\Fmt::tgl($expr); ?>");
        Blade::directive('tglwaktu', fn ($expr) => "<?php echo \\App\\Support\\Fmt::tgl($expr, true); ?>");
        Blade::directive('umurhari', fn ($expr) => "<?php echo \\App\\Support\\Fmt::umurHari($expr); ?>");
    }
}
