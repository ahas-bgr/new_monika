<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseOrder extends Model
{
    protected $fillable = ['project_id', 'number', 'date', 'value', 'file_path'];

    protected function casts(): array
    {
        return ['date' => 'date'];
    }
}
