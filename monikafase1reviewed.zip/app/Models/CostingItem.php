<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CostingItem extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'costing_sheet_id', 'category', 'description',
        'qty', 'unit', 'duration', 'unit_price', 'note', 'sort_order',
    ];

    public const CATEGORIES = [
        'manpower'  => 'Manpower',
        'material'  => 'Material',
        'transport' => 'Transport',
        'alat'      => 'Alat',
        'lain'      => 'Lain-lain',
    ];

    public function costingSheet(): BelongsTo
    {
        return $this->belongsTo(CostingSheet::class);
    }

    public function total(): float
    {
        return (float) $this->qty * (float) $this->duration * (float) $this->unit_price;
    }
}
