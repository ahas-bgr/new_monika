<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CostingSheet extends Model
{
    protected $fillable = [
        'code', 'creator', 'project_name', 'location',
        'cooperation_status', 'deadline_sph', 'kick_off', 'finish',
        'point_count', 'effective_days', 'manpower_count', 'manpower_position',
        'project_type', 'contract_type', 'margin_percent', 'ppn_percent', 'status',
        'notes', 'support_doc_path',
        'plan_sph_price', 'hpp', 'nett_profit_rp', 'nett_profit_percent',
        'dp_in', 'client_budget_estimate', 'market_price', 'ot_level', 'sla_assessment',
        'invoice_mechanism', 'critical_profit_notes', 'additional_notes', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'deadline_sph' => 'date', 'kick_off' => 'date', 'finish' => 'date',
            'margin_percent' => 'decimal:2', 'ppn_percent' => 'decimal:2',
            'plan_sph_price' => 'decimal:2', 'hpp' => 'decimal:2',
        ];
    }

    public const COOPERATION = ['new' => 'New', 'existing' => 'Existing', 'renewal' => 'Renewal'];
    public const PROJECT_TYPES = ['jasa' => 'Jasa', 'barang' => 'Barang', 'jasa_barang' => 'Jasa & Barang'];
    public const CONTRACT_TYPES = ['one_shoot' => 'One Shoot', 'termin' => 'Termin', 'retainer' => 'Retainer'];
    public const STATUSES = ['draft' => 'Draft', 'final' => 'Final', 'approved' => 'Approved'];
    public const OT_LEVELS = ['rendah' => 'Rendah', 'sedang' => 'Sedang', 'tinggi' => 'Tinggi'];
    public const SLA = ['sangat_layak' => 'Sangat Layak', 'layak' => 'Layak', 'dipertimbangkan' => 'Dipertimbangkan', 'tidak_layak' => 'Tidak Layak'];

    public function items(): HasMany
    {
        return $this->hasMany(CostingItem::class)->orderBy('sort_order');
    }

    public function creatorUser(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    /** Nomor Costing berikutnya: CST-YYYYMM-NNNN (urut per bulan). */
    public static function nextCode(): string
    {
        $prefix = 'CST-' . now()->format('Ym') . '-';
        $last = static::where('code', 'like', $prefix . '%')->orderByDesc('code')->value('code');
        $seq = $last ? ((int) substr($last, -4)) + 1 : 1;

        return $prefix . str_pad((string) $seq, 4, '0', STR_PAD_LEFT);
    }
}
