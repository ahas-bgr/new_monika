<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Quotation extends Model
{
    protected $fillable = [
        'project_id', 'parent_quotation_id', 'revision_number', 'number',
        'date', 'valid_until', 'ppn_percent', 'status', 'sent_at',
    ];

    protected function casts(): array
    {
        return ['date' => 'date', 'valid_until' => 'date', 'sent_at' => 'datetime'];
    }

    public function items(): HasMany
    {
        return $this->hasMany(QuotationItem::class);
    }
}
