<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TenderDocument extends Model
{
    protected $fillable = [
        'name', 'valid_until', 'issuer', 'file_path', 'file_name', 'uploaded_by',
    ];

    protected function casts(): array
    {
        return ['valid_until' => 'date'];
    }

    public function uploader(): BelongsTo
    {
        return $this->belongsTo(User::class, 'uploaded_by');
    }

    /** null = tak ada batas; true = kedaluwarsa; false = masih berlaku. */
    public function isExpired(): ?bool
    {
        return $this->valid_until ? $this->valid_until->isPast() : null;
    }

    public function daysLeft(): ?int
    {
        return $this->valid_until ? (int) now()->startOfDay()->diffInDays($this->valid_until, false) : null;
    }
}
