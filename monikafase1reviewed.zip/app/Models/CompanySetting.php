<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CompanySetting extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'id', 'name', 'logo_path', 'address', 'city', 'npwp', 'bank_info',
        'director_name', 'sph_format', 'invoice_format', 'kwitansi_format',
        'stuck_threshold_days',
    ];

    public static function current(): self
    {
        return static::firstOrCreate(['id' => 1], ['name' => 'Perusahaan Anda']);
    }
}
