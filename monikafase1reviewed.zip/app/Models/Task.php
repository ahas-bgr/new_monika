<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Task extends Model
{
    protected $fillable = ['project_id', 'title', 'description', 'assignee_id', 'deadline', 'status'];

    protected function casts(): array
    {
        return ['deadline' => 'date'];
    }

    public function assignee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assignee_id');
    }

    public function isOverdue(): bool
    {
        return $this->status !== 'done'
            && $this->deadline
            && $this->deadline->isPast()
            && ! $this->deadline->isToday();
    }
}
