<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ProjectStatusLog extends Model
{
    public const UPDATED_AT = null;

    protected $fillable = [
        'project_id', 'from_status', 'to_status', 'user_id',
        'note', 'is_override', 'skipped_requirements',
    ];

    protected function casts(): array
    {
        return [
            'is_override'          => 'boolean',
            'skipped_requirements' => 'array',
            'created_at'           => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
