<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PendingRequirement extends Model
{
    public const UPDATED_AT = null;

    protected $fillable = [
        'project_id', 'type', 'status', 'created_by',
        'resolved_at', 'resolved_by', 'resolve_note',
    ];

    protected function casts(): array
    {
        return ['created_at' => 'datetime', 'resolved_at' => 'datetime'];
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(Project::class);
    }
}
