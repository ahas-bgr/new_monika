<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\SoftDeletes;

class Project extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'client_id', 'name', 'description', 'status',
        'value_total', 'po_value', 'cancelled_reason', 'created_by',
    ];

    protected function casts(): array
    {
        return ['value_total' => 'decimal:2', 'po_value' => 'decimal:2'];
    }

    public function client(): BelongsTo
    {
        return $this->belongsTo(Client::class);
    }

    public function statusLogs(): HasMany
    {
        return $this->hasMany(ProjectStatusLog::class)->latest('id');
    }

    public function pendingRequirements(): HasMany
    {
        return $this->hasMany(PendingRequirement::class);
    }

    public function openRequirements(): HasMany
    {
        return $this->pendingRequirements()->where('status', 'open');
    }

    public function quotations(): HasMany
    {
        return $this->hasMany(Quotation::class);
    }

    public function purchaseOrders(): HasMany
    {
        return $this->hasMany(PurchaseOrder::class);
    }

    public function tasks(): HasMany
    {
        return $this->hasMany(Task::class);
    }

    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    public function payments(): HasManyThrough
    {
        return $this->hasManyThrough(Payment::class, Invoice::class);
    }

    public function isActive(): bool
    {
        return ! in_array($this->status, ['selesai', 'dibatalkan'], true);
    }

    public function taskProgress(): array
    {
        $total = $this->tasks->count();
        $done  = $this->tasks->where('status', 'done')->count();

        return [
            'total'   => $total,
            'done'    => $done,
            'percent' => $total ? (int) round($done / $total * 100) : 0,
        ];
    }
}
