# MONIKA v2

Aplikasi web internal monitoring proyek HVAC — memantau siklus proyek dari
penawaran (SPH) hingga pembayaran, dengan pipeline berdisiplin + mekanisme
**override terkendali** dan **hutang dokumen** yang tercatat.

- **Stack:** Laravel 11 (PHP 8.3+), MySQL 8, Livewire 3, Blade. CSS kustom siap
  pakai (`public/assets/style.css`) — tanpa langkah build npm/vite.
- **Status:** Fase 1 — Login & akun, manajemen user, pengaturan perusahaan,
  dashboard (kartu status, panel "Perlu Perhatian", daftar proyek + stepper),
  dan inti state machine `app/Services/ProjectStateService.php`.

Pipeline: `SPH → Menunggu PO → Pengerjaan → BAST → Invoicing → Menunggu Pembayaran → Selesai`

## Setup singkat

Butuh PHP 8.3+, Composer, dan MySQL/MariaDB.

```bash
composer install
cp .env.example .env          # lalu isi kredensial DB (DB_CONNECTION=mysql, dst.)
php artisan key:generate
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Buka http://127.0.0.1:8000 lalu login:

| Peran | Email | Password |
|---|---|---|
| Admin | admin@monika.test | admin123 |
| Staff | budi@monika.test | staff123 |

> **Ganti semua password bawaan** lewat menu Pengguna setelah login pertama.

Panduan lengkap perakitan, deploy ke Hostinger, dan checklist verifikasi ada di
[`SETUP.md`](SETUP.md).

## Aturan emas pengembangan

Jangan pernah mengubah kolom `projects.status` di luar `ProjectStateService`.
Semua transisi (maju, override, rollback, batal) beserta pencatatan log + hutang
dokumen hidup di satu service tersebut.
