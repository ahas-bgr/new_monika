@props(['status'])
@php
    use App\Services\ProjectStateService as P;
    $cls = match ($status) {
        'selesai'             => 'b-teal',
        P::CANCELLED          => 'b-gray',
        'menunggu_pembayaran' => 'b-amber',
        default               => 'b-navy',
    };
@endphp
<span class="badge {{ $cls }}">{{ P::label($status) }}</span>
