@props(['status', 'large' => false])
@php
    use App\Services\ProjectStateService as P;
    $keys   = array_keys(P::STATUSES);
    $cancel = $status === P::CANCELLED;
    $now    = $cancel ? -1 : P::index($status);
@endphp
<div class="stepper {{ $large ? 'stepper-lg' : '' }}" role="img" aria-label="Tahap: {{ P::label($status) }}">
  @foreach ($keys as $i => $key)
    @if ($i > 0)
      <span class="step-link {{ $cancel ? 'cancel' : ($i <= $now ? 'done' : '') }}"></span>
    @endif
    <span class="step {{ $cancel ? 'cancel' : ($i < $now ? 'done' : ($i === $now ? 'now' : '')) }}"
          title="{{ P::STATUSES[$key] }}"></span>
  @endforeach
</div>
@if ($large)
  <div class="stepper-labels">
    @foreach ($keys as $i => $key)
      <span class="{{ $cancel ? '' : ($i < $now ? 'done' : ($i === $now ? 'now' : '')) }}">{{ P::STATUSES[$key] }}</span>
    @endforeach
  </div>
@endif
