<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{ $title ?? 'MONIKA' }} – MONIKA</title>
<link rel="icon" href="{{ asset('assets/logo.png') }}" type="image/png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="{{ asset('assets/style.css') }}">
</head>
<body>
@php $company = \App\Models\CompanySetting::current(); @endphp
<div class="app-shell">
  <aside class="sidebar">
    <a class="side-brand" href="{{ route('dashboard') }}" wire:navigate>
      <img src="{{ $company->logo_path ? asset('storage/' . $company->logo_path) : asset('assets/logo.png') }}" alt="Logo MONIKA">
      <span><b>MONIKA</b><small>Monitor Proyek &amp; Keuangan</small></span>
    </a>

    <nav class="side-nav">
      <div class="side-group">Monitoring Project</div>
      <a href="{{ route('dashboard') }}" wire:navigate class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">Dashboard</a>
      <a href="{{ route('projects.index') }}" wire:navigate class="{{ request()->routeIs('projects.*') ? 'active' : '' }}">List Project</a>
      <a href="{{ route('costing.index') }}" wire:navigate class="{{ request()->routeIs('costing.*') ? 'active' : '' }}">Costing Sheet</a>
      <a href="{{ route('tender.index') }}" wire:navigate class="{{ request()->routeIs('tender.*') ? 'active' : '' }}">Dokumen Tender</a>

      <div class="side-group">Database</div>
      <a href="{{ route('clients.index') }}" wire:navigate class="{{ request()->routeIs('clients.*') ? 'active' : '' }}">Customer</a>
      @if (auth()->user()->isAdmin())
        <a href="{{ route('users.index') }}" wire:navigate class="{{ request()->routeIs('users.*') ? 'active' : '' }}">List User &amp; Authority</a>
        <a href="{{ route('settings') }}" wire:navigate class="{{ request()->routeIs('settings') ? 'active' : '' }}">Pengaturan Perusahaan</a>
      @endif
    </nav>

    <form method="POST" action="{{ route('logout') }}" class="side-logout">
      @csrf
      <button type="submit">&#8618; Logout</button>
    </form>
  </aside>

  <main class="main">
    <header class="main-top">
      <div class="main-top-title">{{ $title ?? 'MONIKA' }}</div>
      <div class="main-top-user">
        <span><b>{{ auth()->user()->name }}</b> · {{ auth()->user()->isAdmin() ? 'Admin' : 'Staff' }}</span>
      </div>
    </header>

    <div class="wrap">
      @foreach (['ok', 'err', 'warn'] as $type)
        @if (session($type))
          <div class="flash {{ $type }}">{{ session($type) }}</div>
        @endif
      @endforeach

      {{ $slot }}
    </div>
  </main>
</div>
</body>
</html>
