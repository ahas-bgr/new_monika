<div>
  <div class="page-head">
    <div><h1>Dokumen Tender</h1>
      <div class="sub">Legalitas & sertifikat perusahaan beserta masa berlakunya</div></div>
    <button type="button" class="btn btn-primary" wire:click="openForm">+ Upload Dokumen Tender</button>
  </div>

  <div class="card">
    <div class="card-body tight table-scroll">
      <table class="table">
        <thead>
          <tr><th>Nama Dokumen</th><th>Penerbit</th><th>Berlaku s.d.</th><th>Status</th><th>Diunggah</th><th></th></tr>
        </thead>
        <tbody>
          @forelse ($documents as $doc)
            @php $days = $doc->daysLeft(); @endphp
            <tr>
              <td>
                <a href="{{ asset('storage/' . $doc->file_path) }}" target="_blank"><b>{{ $doc->name }}</b></a>
                <div class="meta">{{ $doc->file_name }}</div>
              </td>
              <td>{{ $doc->issuer ?: '–' }}</td>
              <td>{{ $doc->valid_until ? \App\Support\Fmt::tgl($doc->valid_until) : 'Tanpa batas' }}</td>
              <td>
                @if ($doc->isExpired() === null)
                  <span class="badge b-gray">Permanen</span>
                @elseif ($doc->isExpired())
                  <span class="badge b-coral">Kedaluwarsa</span>
                @elseif ($days !== null && $days <= 30)
                  <span class="badge b-amber">{{ $days }} hari lagi</span>
                @else
                  <span class="badge b-teal">Aktif</span>
                @endif
              </td>
              <td class="meta">{{ $doc->uploader?->name ?? '–' }}<br>@tgl($doc->created_at)</td>
              <td style="text-align:right">
                <a href="{{ asset('storage/' . $doc->file_path) }}" target="_blank" class="btn btn-sm">Lihat</a>
                <button type="button" class="btn btn-sm btn-danger"
                        wire:click="delete({{ $doc->id }})"
                        wire:confirm="Hapus dokumen '{{ $doc->name }}'?">Hapus</button>
              </td>
            </tr>
          @empty
            <tr><td colspan="6" class="muted" style="text-align:center;padding:24px">Belum ada dokumen tender. Klik “Upload Dokumen Tender”.</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>

  @if ($showForm)
    <div class="modal-overlay" wire:key="tender-modal">
      <div class="modal">
        <div class="modal-head">
          <h2>&#128193; Upload Dokumen Tender</h2>
          <button type="button" class="modal-x" wire:click="$set('showForm', false)">&times;</button>
        </div>
        <form wire:submit="save">
          <div class="modal-body">
            <div class="field"><label>Nama Dokumen <span style="color:var(--coral-700)">*</span></label>
              <input type="text" wire:model="name" placeholder="Contoh: Sertifikat BPJS Ketenagakerjaan">
              @error('name') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
            </div>
            <div class="field"><label>Berlaku s.d.</label>
              <input type="date" wire:model="valid_until">
              <div class="hint">Kosongkan jika tidak ada batas berlaku</div>
            </div>
            <div class="field"><label>Penerbit</label>
              <input type="text" wire:model="issuer" placeholder="Contoh: BPJS Ketenagakerjaan, DJP, dst.">
            </div>
            <div class="field"><label>File Dokumen <span style="color:var(--coral-700)">*</span></label>
              <input type="file" wire:model="file">
              <div class="hint">PDF, DOC, DOCX, JPG, PNG, XLS, PPTX — maks. 10 MB</div>
              <div wire:loading wire:target="file" class="small muted">Mengunggah…</div>
              @error('file') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
            </div>
          </div>
          <div class="modal-foot">
            <button type="button" class="btn" wire:click="$set('showForm', false)">Batal</button>
            <button type="submit" class="btn btn-primary" wire:loading.attr="disabled" wire:target="save,file">&#128190; Simpan</button>
          </div>
        </form>
      </div>
    </div>
  @endif
</div>
