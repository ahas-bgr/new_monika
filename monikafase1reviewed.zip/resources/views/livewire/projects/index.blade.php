@php use App\Services\ProjectStateService as P; @endphp
<div>
  <div class="page-head">
    <div>
      <h1>{{ $bucketLabel ?? 'Semua Proyek' }}</h1>
      <div class="sub">
        {{ $projects->count() }} proyek ditampilkan
        @if ($bucketLabel)
          · <button type="button" class="linklike" wire:click="clearBucket">✕ hapus filter kotak</button>
        @endif
      </div>
    </div>
    <div style="display:flex;gap:10px">
      <button class="btn btn-teal" wire:click="export" wire:loading.attr="disabled" wire:target="export">&#8681; Download Excel</button>
      <a class="btn btn-primary" href="{{ route('projects.create') }}" wire:navigate>+ Proyek Baru</a>
    </div>
  </div>

  @if ($bucketLabel)
    <div class="flash" style="background:var(--navy-50);color:var(--navy-700);border:1px solid var(--navy-100)">
      Menampilkan kotak <b>{{ $bucketLabel }}</b>. Filter di bawah tetap bisa dipakai untuk mempersempit.
    </div>
  @endif

  <div class="card">
    <div class="card-body">
      <div class="filters">
        <div class="field"><label>Cari</label>
          <input type="text" wire:model.live.debounce.400ms="search" placeholder="Nama proyek / klien"></div>
        <div class="field"><label>Status</label>
          <select wire:model.live="status">
            <option value="">Semua</option>
            @foreach ($statuses as $key => $label)
              <option value="{{ $key }}">{{ $label }}</option>
            @endforeach
            <option value="{{ P::CANCELLED }}">Dibatalkan</option>
          </select>
        </div>
        <div class="field"><label>Klien</label>
          <select wire:model.live="client">
            <option value="0">Semua</option>
            @foreach ($clients as $c)
              <option value="{{ $c->id }}">{{ $c->name }}</option>
            @endforeach
          </select>
        </div>
        <div class="field"><label>Dibuat dari</label><input type="date" wire:model.live="d1"></div>
        <div class="field"><label>Sampai</label><input type="date" wire:model.live="d2"></div>
        <button class="btn btn-outline" wire:click="resetFilters">Reset</button>
      </div>
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-body tight table-scroll" wire:loading.class="muted">
      <table class="table">
        <thead><tr><th>Proyek</th><th>Klien</th><th>Pipeline</th><th>Status</th><th class="right">Nilai SPH</th><th class="right">Nilai PO</th><th>Dibuat</th><th>Update</th></tr></thead>
        <tbody>
        @forelse ($projects as $p)
          <tr wire:key="proj-{{ $p->id }}">
            <td>
              <a href="{{ route('projects.show', $p) }}" wire:navigate><b>{{ $p->name }}</b></a>
              @if ($p->pending_open > 0)<span class="badge b-amber">⚠ {{ $p->pending_open }} menyusul</span>@endif
            </td>
            <td>{{ $p->client->name }}<div class="small muted">{{ $p->client->company }}</div></td>
            <td><x-stepper :status="$p->status" /></td>
            <td><x-status-badge :status="$p->status" /></td>
            <td class="right">@rupiah($p->value_total)</td>
            <td class="right">{{ $p->po_value !== null ? \App\Support\Fmt::rupiah($p->po_value) : '–' }}</td>
            <td class="small muted">@tgl($p->created_at)</td>
            <td class="small muted">@tgl($p->updated_at)</td>
          </tr>
        @empty
          <tr><td colspan="8" class="muted" style="padding:20px">Tidak ada proyek pada filter ini.</td></tr>
        @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>
