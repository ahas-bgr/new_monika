@php use App\Services\ProjectStateService as P; @endphp
<div>
  <div class="page-head">
    <div>
      <h1>{{ $project->name }}</h1>
      <div class="sub">
        Klien: <b>{{ $project->client->name }}</b>@if($project->client->company) — {{ $project->client->company }}@endif
        · Nilai: <b>@rupiah($project->value_total)</b>
      </div>
    </div>
    <div class="row-actions">
      <x-status-badge :status="$project->status" />
      <a class="btn btn-outline btn-sm" href="{{ route('projects.edit', $project) }}" wire:navigate>Edit</a>
    </div>
  </div>

  @if ($project->status === P::CANCELLED)
    <div class="flash err">Proyek ini dibatalkan. Alasan: {{ $project->cancelled_reason ?: '-' }}</div>
  @endif

  <div class="card">
    <div class="card-body">
      <x-stepper :status="$project->status" :large="true" />
    </div>
  </div>

  @if ($project->openRequirements->isNotEmpty())
    <div class="card attn section-gap">
      <div class="card-head"><h2>⚠ Dokumen Menyusul ({{ $project->openRequirements->count() }})</h2></div>
      <ul>
        @foreach ($project->openRequirements as $req)
          <li wire:key="req-{{ $req->id }}">
            <b>{{ $reqLabels[$req->type] ?? $req->type }}</b>
            <div class="meta">Di-override @tgl($req->created_at) · sudah <b>@umurhari($req->created_at) hari</b></div>
            @if (auth()->user()->isAdmin())
              <div class="row-actions mt-2">
                <input type="text" wire:model="resolveNotes.{{ $req->id }}"
                       placeholder="Catatan pelengkapan (mis. no. PO)" style="max-width:280px">
                <button class="btn btn-sm btn-warn" wire:click="resolveRequirement({{ $req->id }})">Tandai Lengkap</button>
              </div>
            @endif
          </li>
        @endforeach
      </ul>
    </div>
  @endif

  @unless ($isFinal)
    <div class="card section-gap">
      <div class="card-head">
        <h2>Aksi Tahap: {{ P::label($project->status) }}@if($nextStatus) → {{ P::label($nextStatus) }}@endif</h2>
      </div>
      <div class="card-body">
        @if ($unmet)
          <div class="flash warn" style="margin-bottom:14px">
            Syarat untuk maju belum terpenuhi:
            <ul style="margin:6px 0 0 18px">
              @foreach ($unmet as $req)
                <li>{{ $reqLabels[$req] }}</li>
              @endforeach
            </ul>
          </div>
        @endif

        <div class="row-actions">
          <button class="btn btn-primary" wire:click="advance"
                  @if($unmet) disabled title="Syarat belum terpenuhi" @endif
                  wire:loading.attr="disabled">
            Lanjut ke {{ P::label($nextStatus) }}
          </button>

          @if (auth()->user()->isAdmin() && $unmet)
            <details>
              <summary class="btn btn-warn" style="list-style:none">Override (Lanjut Tanpa Syarat Lengkap)</summary>
              <div class="mt-2" style="max-width:460px">
                <p class="small muted">Syarat yang dilewati akan tercatat sebagai <b>dokumen menyusul</b> dan proyek tidak bisa Selesai sebelum dilengkapi.</p>
                <textarea wire:model="overrideNote"
                          placeholder="Alasan override — wajib, min. 10 karakter (mis. PO menyusul, klien minta kerja dimulai per telepon Pak Budi 7/7)"></textarea>
                <button class="btn btn-warn mt-2" wire:click="override" wire:loading.attr="disabled">Konfirmasi Override</button>
              </div>
            </details>
          @endif

          @if (auth()->user()->isAdmin() && $prevStatus)
            <details>
              <summary class="btn btn-outline" style="list-style:none">Mundur Satu Tahap</summary>
              <div class="mt-2" style="max-width:460px">
                <textarea wire:model="rollbackNote" placeholder="Alasan koreksi — wajib, min. 10 karakter"></textarea>
                <button class="btn btn-outline mt-2" wire:click="rollback" wire:loading.attr="disabled">
                  Konfirmasi Mundur ke {{ P::label($prevStatus) }}
                </button>
              </div>
            </details>
          @endif

          @if (auth()->user()->isAdmin())
            <details>
              <summary class="btn btn-danger" style="list-style:none">Batalkan Proyek</summary>
              <div class="mt-2" style="max-width:460px">
                <textarea wire:model="cancelNote" placeholder="Alasan pembatalan — wajib, min. 10 karakter"></textarea>
                <button class="btn btn-danger mt-2" wire:click="cancelProject"
                        wire:confirm="Yakin membatalkan proyek ini?" wire:loading.attr="disabled">
                  Konfirmasi Pembatalan
                </button>
              </div>
            </details>
          @endif
        </div>
      </div>
    </div>
  @endunless

  <div class="card section-gap">
    <div class="card-head">
      <h2>Task Pengerjaan</h2>
      <span class="badge {{ $progress['percent'] === 100 && $progress['total'] ? 'b-teal' : 'b-navy' }}">
        {{ $progress['done'] }}/{{ $progress['total'] }} selesai ({{ $progress['percent'] }}%)
      </span>
    </div>
    <div class="card-body">
      @unless ($isFinal)
        <div class="row-actions" style="margin-bottom:14px">
          <input type="text" wire:model="newTaskTitle" wire:keydown.enter="addTask"
                 placeholder="Task baru… (mis. Instalasi unit outdoor lt. 3)" style="flex:1;min-width:200px">
          <input type="date" wire:model="newTaskDeadline" style="width:160px" title="Deadline (opsional)">
          <button class="btn btn-outline" wire:click="addTask" wire:loading.attr="disabled">+ Tambah</button>
        </div>
        @error('newTaskTitle') <p class="small" style="color:var(--coral-700);margin-bottom:10px">{{ $message }}</p> @enderror
      @endunless

      @if ($project->tasks->isEmpty())
        <p class="muted small">Belum ada task. Tambahkan task untuk mengukur progres tahap Pengerjaan — syarat maju ke Invoicing adalah semua task selesai.</p>
      @else
        <table class="table">
          <tbody>
          @foreach ($project->tasks as $task)
            <tr wire:key="task-{{ $task->id }}">
              <td style="width:36px">
                <button class="btn btn-sm {{ $task->status === 'done' ? 'btn-primary' : 'btn-outline' }}"
                        wire:click="toggleTask({{ $task->id }})" title="Tandai selesai / belum"
                        @if($isFinal) disabled @endif>
                  {{ $task->status === 'done' ? '✓' : '○' }}
                </button>
              </td>
              <td @if($task->status === 'done') style="text-decoration:line-through;color:var(--ink-faint)" @endif>
                {{ $task->title }}
              </td>
              <td class="small muted" style="width:180px">
                @if ($task->deadline)
                  Deadline @tgl($task->deadline)
                  @if ($task->isOverdue())
                    <span class="badge b-coral">lewat</span>
                  @endif
                @endif
              </td>
            </tr>
          @endforeach
          </tbody>
        </table>
      @endif
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-head"><h2>Timeline &amp; Riwayat Status</h2></div>
    <div class="card-body">
      <ul class="timeline">
        @foreach ($project->statusLogs as $log)
          <li class="{{ $log->is_override ? 'ovr' : '' }}" wire:key="log-{{ $log->id }}">
            <div class="t-title">
              @if($log->from_status){{ P::label($log->from_status) }} → @endif{{ P::label($log->to_status) }}
              @if ($log->is_override)<span class="badge b-amber">OVERRIDE</span>@endif
            </div>
            <div class="t-meta">{{ $log->user->name ?? 'Sistem' }} · @tglwaktu($log->created_at)</div>
            @if ($log->note)<div class="t-note">{{ $log->note }}</div>@endif
            @if ($log->skipped_requirements)
              <div class="t-note">
                Syarat dilewati: {{ collect($log->skipped_requirements)->map(fn ($r) => $reqLabels[$r] ?? $r)->join('; ') }}
              </div>
            @endif
          </li>
        @endforeach
      </ul>
    </div>
  </div>
</div>
