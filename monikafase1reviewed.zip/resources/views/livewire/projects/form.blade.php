<div>
  <div class="page-head">
    <div>
      <h1>{{ $project ? 'Edit Proyek' : 'Proyek Baru' }}</h1>
      <div class="sub">{{ $project ? $project->name : 'Proyek baru selalu mulai dari tahap SPH Draft' }}</div>
    </div>
  </div>

  <div class="card" style="max-width:640px">
    <div class="card-body">
      @if ($clients->isEmpty())
        <div class="flash warn">Belum ada klien.
          <a href="{{ route('clients.index') }}" wire:navigate>Tambah klien dulu</a> sebelum membuat proyek.</div>
      @endif

      <form wire:submit="save">
        <div class="field">
          <label>Nama Proyek</label>
          <input type="text" wire:model="name" maxlength="180" placeholder="mis. Instalasi HVAC Gedung B">
          @error('name') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
        </div>
        <div class="form-grid">
          <div class="field">
            <label>Klien</label>
            <select wire:model="client_id">
              <option value="">— pilih klien —</option>
              @foreach ($clients as $c)
                <option value="{{ $c->id }}">{{ $c->name }}@if($c->company) — {{ $c->company }}@endif</option>
              @endforeach
            </select>
            @error('client_id') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field">
            <label>Nilai Proyek (Rp) <span class="hint">perkiraan, bisa diubah</span></label>
            <input type="text" wire:model="value_total" inputmode="numeric" placeholder="mis. 25.000.000">
          </div>
        </div>
        <div class="field">
          <label>Deskripsi <span class="hint">opsional</span></label>
          <textarea wire:model="description" placeholder="Ringkasan lingkup pekerjaan…"></textarea>
        </div>
        <div class="row-actions">
          <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
            {{ $project ? 'Simpan Perubahan' : 'Buat Proyek' }}
          </button>
          <a class="btn btn-outline" href="{{ $project ? route('projects.show', $project) : route('projects.index') }}" wire:navigate>Batal</a>
        </div>
      </form>
    </div>
  </div>
</div>
