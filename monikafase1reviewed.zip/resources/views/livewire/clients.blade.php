<div>
  <div class="page-head">
    <div><h1>Master Data Klien</h1><div class="sub">{{ $clients->count() }} klien terdaftar</div></div>
  </div>

  <div class="card" style="max-width:680px">
    <div class="card-head">
      <h2>{{ $editId ? 'Edit Klien' : 'Tambah Klien' }}</h2>
      @if ($editId)
        <button class="btn btn-outline btn-sm" wire:click="cancelEdit">+ Mode Tambah</button>
      @endif
    </div>
    <div class="card-body">
      <form wire:submit="save">
        <div class="form-grid">
          <div class="field"><label>Nama Kontak</label>
            <input type="text" wire:model="name">
            @error('name') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field"><label>Perusahaan</label><input type="text" wire:model="company"></div>
          <div class="field"><label>Email</label>
            <input type="email" wire:model="email">
            @error('email') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field"><label>Telepon / WA</label><input type="text" wire:model="phone"></div>
        </div>
        <div class="field"><label>Alamat</label><textarea wire:model="address" style="min-height:56px"></textarea></div>
        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">
          {{ $editId ? 'Simpan Perubahan' : 'Tambah Klien' }}
        </button>
      </form>
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-body tight table-scroll">
      <table class="table">
        <thead><tr><th>Nama</th><th>Perusahaan</th><th>Kontak</th><th>Proyek</th><th></th></tr></thead>
        <tbody>
        @foreach ($clients as $c)
          <tr wire:key="client-{{ $c->id }}">
            <td><b>{{ $c->name }}</b></td>
            <td>{{ $c->company }}</td>
            <td class="small">{{ $c->phone }}@if($c->email)<div class="muted">{{ $c->email }}</div>@endif</td>
            <td><a href="{{ route('projects.index', ['client' => $c->id]) }}" wire:navigate>{{ $c->projects_count }} proyek</a></td>
            <td class="right"><button class="btn btn-outline btn-sm" wire:click="edit({{ $c->id }})">Edit</button></td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
