<div>
  <div class="page-head">
    <div><h1>Manajemen Pengguna</h1><div class="sub">Khusus admin</div></div>
  </div>

  <div class="card" style="max-width:680px">
    <div class="card-head"><h2>Tambah Pengguna</h2></div>
    <div class="card-body">
      <form wire:submit="addUser">
        <div class="form-grid">
          <div class="field"><label>Nama</label>
            <input type="text" wire:model="name">
            @error('name') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field"><label>Email</label>
            <input type="email" wire:model="email">
            @error('email') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field"><label>Password Awal</label>
            <input type="text" wire:model="password" placeholder="min. 6 karakter">
            @error('password') <p class="small" style="color:var(--coral-700)">{{ $message }}</p> @enderror
          </div>
          <div class="field"><label>Peran</label>
            <select wire:model="role"><option value="staff">Staff</option><option value="admin">Admin</option></select>
          </div>
        </div>
        <button type="submit" class="btn btn-primary" wire:loading.attr="disabled">Tambah Pengguna</button>
      </form>
    </div>
  </div>

  <div class="card section-gap">
    <div class="card-body tight table-scroll">
      <table class="table">
        <thead><tr><th>Nama</th><th>Email</th><th>Peran</th><th>Status</th><th></th></tr></thead>
        <tbody>
        @foreach ($users as $u)
          <tr wire:key="user-{{ $u->id }}">
            <td><b>{{ $u->name }}</b> @if($u->id === auth()->id())<span class="badge b-navy">Anda</span>@endif</td>
            <td>{{ $u->email }}</td>
            <td><span class="badge {{ $u->role === 'admin' ? 'b-purple' : 'b-gray' }}">{{ ucfirst($u->role) }}</span></td>
            <td><span class="badge {{ $u->is_active ? 'b-teal' : 'b-coral' }}">{{ $u->is_active ? 'Aktif' : 'Nonaktif' }}</span></td>
            <td>
              <div class="row-actions">
                <button class="btn btn-outline btn-sm" wire:click="toggleActive({{ $u->id }})"
                        wire:confirm="Ubah status aktif pengguna ini?">
                  {{ $u->is_active ? 'Nonaktifkan' : 'Aktifkan' }}
                </button>
                <details>
                  <summary class="btn btn-outline btn-sm" style="list-style:none">Reset Password</summary>
                  <div class="row-actions mt-2">
                    <input type="text" wire:model="resetPasswords.{{ $u->id }}" placeholder="Password baru" style="width:150px">
                    <button class="btn btn-warn btn-sm" wire:click="resetPassword({{ $u->id }})">Simpan</button>
                  </div>
                </details>
              </div>
            </td>
          </tr>
        @endforeach
        </tbody>
      </table>
    </div>
  </div>
</div>
