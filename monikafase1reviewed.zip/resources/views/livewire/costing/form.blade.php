@php use App\Models\CostingSheet; @endphp
<div>
  <form wire:submit="save">
    {{-- Header band --}}
    <div class="costing-band">
      <div>
        <div class="cb-sub">MONIKA — Monitoring Project dan Keuangan</div>
        <div class="cb-title">Costing Sheet</div>
      </div>
      <div class="cb-code"><small>Kode Costing</small><b>{{ $code }}</b></div>
    </div>

    {{-- Informasi Project --}}
    <div class="card section-gap">
      <div class="card-head"><h2>Informasi Project</h2></div>
      <div class="card-body">
        <div class="form-grid cols-4">
          <div class="field"><label>Kode Costing</label><input type="text" value="{{ $code }}" disabled></div>
          <div class="field"><label>Creator</label><input type="text" wire:model="creator" placeholder="Nama pembuat costing"></div>
          <div class="field"><label>Nama Project <span class="req">*</span></label><input type="text" wire:model.blur="project_name">
            @error('project_name') <p class="err-msg">{{ $message }}</p> @enderror</div>
          <div class="field"><label>Lokasi</label><input type="text" wire:model="location"></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>Status Kerjasama</label>
            <select wire:model="cooperation_status">@foreach (CostingSheet::COOPERATION as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
          <div class="field"><label>Deadline SPH</label><input type="date" wire:model="deadline_sph"></div>
          <div class="field"><label>Kick Off</label><input type="date" wire:model="kick_off"></div>
          <div class="field"><label>Selesai</label><input type="date" wire:model="finish"></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>Jumlah Titik</label><input type="number" min="0" wire:model="point_count"></div>
          <div class="field"><label>Hari Efektif</label><input type="number" min="0" wire:model="effective_days"></div>
          <div class="field"><label>Jumlah Manpower</label><input type="number" min="0" wire:model="manpower_count"></div>
          <div class="field"><label>Jabatan Manpower</label><input type="text" wire:model="manpower_position" placeholder="Supervisor, Teknisi Senior, Helper"></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>Jenis Project</label>
            <select wire:model="project_type">@foreach (CostingSheet::PROJECT_TYPES as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
          <div class="field"><label>Jenis Kontrak</label>
            <select wire:model="contract_type">@foreach (CostingSheet::CONTRACT_TYPES as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
          <div class="field"><label>Margin %</label><input type="number" step="0.01" min="0" wire:model.live.debounce.500ms="margin_percent"></div>
          <div class="field"><label>PPN %</label><input type="number" step="0.01" min="0" wire:model.live.debounce.500ms="ppn_percent"></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>Status</label>
            <select wire:model="status">@foreach (CostingSheet::STATUSES as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
        </div>
        <div class="field"><label>Catatan Project</label><textarea wire:model="notes" style="min-height:60px"></textarea></div>
        <div class="field"><label>Upload Dokumen Pendukung <span class="hint">maks 10 MB · Word, PDF, gambar, ZIP/RAR</span></label>
          <input type="file" wire:model="support_doc">
          <div wire:loading wire:target="support_doc" class="small muted">Mengunggah…</div>
          @if ($support_doc_path)<p class="small muted mt-2">Terlampir: {{ basename($support_doc_path) }}</p>@endif
        </div>
      </div>
    </div>

    {{-- Komponen Biaya --}}
    <div class="card section-gap">
      <div class="card-head"><h2>Komponen Biaya</h2>
        <button type="button" class="btn btn-teal btn-sm" wire:click="addItem">+ Tambah Item</button></div>
      <div class="card-body tight table-scroll">
        <table class="table costing-items">
          <thead><tr>
            <th>Kategori</th><th>Deskripsi</th><th>Qty</th><th>Satuan</th><th>Durasi</th>
            <th>Harga Satuan</th><th style="text-align:right">Total</th><th>Ket.</th><th></th>
          </tr></thead>
          <tbody>
            @foreach ($items as $key => $it)
              <tr wire:key="citem-{{ $key }}">
                <td><select wire:model.live="items.{{ $key }}.category" class="cell">@foreach ($categories as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></td>
                <td><input type="text" wire:model.blur="items.{{ $key }}.description" class="cell"></td>
                <td><input type="number" step="0.01" min="0" wire:model.live.debounce.500ms="items.{{ $key }}.qty" class="cell num"></td>
                <td><input type="text" wire:model.blur="items.{{ $key }}.unit" class="cell" style="width:70px"></td>
                <td><input type="number" step="0.01" min="0" wire:model.live.debounce.500ms="items.{{ $key }}.duration" class="cell num"></td>
                <td><input type="number" step="1" min="0" wire:model.live.debounce.500ms="items.{{ $key }}.unit_price" class="cell num"></td>
                <td style="text-align:right;white-space:nowrap"><b>@rupiah($this->itemTotal($it))</b></td>
                <td><input type="text" wire:model.blur="items.{{ $key }}.note" class="cell"></td>
                <td><button type="button" class="btn-x" wire:click="removeItem({{ $key }})" title="Hapus">&times;</button></td>
              </tr>
            @endforeach
            @if (empty($items))
              <tr><td colspan="9" class="muted" style="text-align:center;padding:16px">Belum ada item. Klik “+ Tambah Item”.</td></tr>
            @endif
          </tbody>
        </table>
      </div>
    </div>

    {{-- Feasibility & Profit Review --}}
    <div class="card section-gap">
      <div class="card-head"><h2>Feasibility &amp; Profit Review</h2></div>
      <div class="card-body">
        <div class="form-grid cols-4">
          <div class="field"><label>Rencana Harga SPH</label>
            <input type="number" step="1" min="0" wire:model.live.debounce.500ms="plan_sph_price"></div>
          <div class="field"><label>HPP / Total Biaya</label>
            <input type="text" value="@rupiah($this->subtotalHpp)" disabled></div>
          <div class="field"><label>Potensi Nett Profit (Rp)</label>
            <input type="text" value="@rupiah($this->nettProfitRp)" disabled
              style="color:{{ $this->nettProfitRp >= 0 ? 'var(--teal-600)' : 'var(--coral-700)' }};font-weight:700"></div>
          <div class="field"><label>Potensi Nett Profit (%)</label>
            <input type="text" value="{{ number_format($this->nettProfitPercent, 2, ',', '.') }}%" disabled></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>DP Masuk</label><input type="number" step="1" min="0" wire:model="dp_in"></div>
          <div class="field"><label>Budget Estimasi Klien</label><input type="number" step="1" min="0" wire:model="client_budget_estimate"></div>
          <div class="field"><label>Harga Pasar / Kompetitor</label><input type="number" step="1" min="0" wire:model="market_price"></div>
          <div class="field"><label>Potensi Tingkat Lembur (OT)</label>
            <select wire:model="ot_level">@foreach (CostingSheet::OT_LEVELS as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
        </div>
        <div class="form-grid cols-4">
          <div class="field"><label>Penilaian Akhir Tim SLA</label>
            <select wire:model="sla_assessment">@foreach (CostingSheet::SLA as $k => $v)<option value="{{ $k }}">{{ $v }}</option>@endforeach</select></div>
        </div>
        <div class="field"><label>Mekanisme Invoice / TOP</label>
          <textarea wire:model="invoice_mechanism" style="min-height:52px" placeholder="Contoh: DP 30%, termin 50%, pelunasan 20% setelah BAST"></textarea></div>
        <div class="field"><label>Catatan Titik Kritis Profit</label>
          <textarea wire:model="critical_profit_notes" style="min-height:52px" placeholder="Issue biaya lembur, material, contingency, atau biaya lainnya"></textarea></div>
        <div class="field"><label>Catatan Tambahan</label>
          <textarea wire:model="additional_notes" style="min-height:52px" placeholder="Catatan tambahan feasibility / keputusan internal"></textarea></div>
      </div>
    </div>

    {{-- Ringkasan + aksi --}}
    <div class="card section-gap">
      <div class="card-body costing-foot">
        <div class="costing-note">
          <b>Catatan:</b> Semua item yang diinput akan masuk ke detail dan print.
          Khusus kategori <b>MANPOWER</b> dengan Qty 0 otomatis tidak disimpan.
        </div>
        <div class="costing-summary">
          <div><span>Subtotal HPP</span><b>@rupiah($this->subtotalHpp)</b></div>
          <div><span>Margin ({{ rtrim(rtrim(number_format((float)$margin_percent,2,',','.'),'0'),',') }}%)</span><b>@rupiah($this->marginRp)</b></div>
          <div><span>DPP</span><b>@rupiah($this->dpp)</b></div>
          <div><span>PPN ({{ rtrim(rtrim(number_format((float)$ppn_percent,2,',','.'),'0'),',') }}%)</span><b>@rupiah($this->ppnRp)</b></div>
          <div class="grand"><span>Grand Total</span><b>@rupiah($this->grandTotal)</b></div>
        </div>
      </div>
    </div>

    <div class="form-actions">
      <a href="{{ route('costing.index') }}" wire:navigate class="btn">Batal</a>
      <button type="submit" class="btn btn-primary" wire:loading.attr="disabled" wire:target="save,support_doc">&#128190; Simpan Costing Sheet</button>
    </div>
  </form>
</div>
