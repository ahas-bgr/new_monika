@php use App\Models\CostingSheet; @endphp
<div>
  <div class="page-head">
    <div><h1>Costing Sheet</h1>
      <div class="sub">Kalkulasi biaya & kelayakan profit sebelum SPH diterbitkan</div></div>
    <a href="{{ route('costing.create') }}" wire:navigate class="btn btn-primary">+ Buat Costing</a>
  </div>

  <div class="card">
    <div class="card-body tight table-scroll">
      <table class="table">
        <thead>
          <tr><th>Kode</th><th>Project</th><th>Status</th><th style="text-align:right">HPP</th>
            <th style="text-align:right">Rencana SPH</th><th style="text-align:right">Nett Profit</th><th></th></tr>
        </thead>
        <tbody>
          @forelse ($sheets as $s)
            <tr>
              <td><a href="{{ route('costing.edit', $s) }}" wire:navigate><b>{{ $s->code }}</b></a>
                <div class="meta">{{ $s->creator ?: '–' }} · @tgl($s->created_at)</div></td>
              <td>{{ $s->project_name ?: '—' }}<div class="meta">{{ $s->location }}</div></td>
              <td><span class="badge {{ $s->status === 'approved' ? 'b-teal' : ($s->status === 'final' ? 'b-navy' : 'b-gray') }}">{{ CostingSheet::STATUSES[$s->status] }}</span></td>
              <td style="text-align:right">@rupiah($s->hpp)</td>
              <td style="text-align:right">@rupiah($s->plan_sph_price)</td>
              <td style="text-align:right">
                <b style="color:{{ $s->nett_profit_rp >= 0 ? 'var(--teal-600)' : 'var(--coral-700)' }}">@rupiah($s->nett_profit_rp)</b>
                <div class="meta">{{ number_format((float) $s->nett_profit_percent, 1, ',', '.') }}%</div>
              </td>
              <td style="text-align:right;white-space:nowrap">
                <a href="{{ route('costing.edit', $s) }}" wire:navigate class="btn btn-sm">Edit</a>
                <button type="button" class="btn btn-sm btn-danger" wire:click="delete({{ $s->id }})"
                        wire:confirm="Hapus costing {{ $s->code }}?">Hapus</button>
              </td>
            </tr>
          @empty
            <tr><td colspan="7" class="muted" style="text-align:center;padding:24px">Belum ada costing sheet. Klik “Buat Costing”.</td></tr>
          @endforelse
        </tbody>
      </table>
    </div>
  </div>
</div>
