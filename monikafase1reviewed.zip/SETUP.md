# MONIKA v2 (Laravel) — Fase 1: Panduan Setup

Paket ini adalah **overlay kode aplikasi**: semua file MONIKA yang ditaruh di atas
kerangka Laravel 11 yang baru. Perakitan butuh `composer` (tersedia di komputer
Windows/Mac/Linux, atau via SSH Hostinger pada paket Business/Cloud).

> Logika state machine di `app/Services/ProjectStateService.php` adalah port 1:1
> dari versi PHP native yang sudah lolos pengujian menyeluruh (gating, override,
> rollback, guard pembayaran, guard dokumen menyusul).

---

## A. Perakitan (sekali jalan, ±5 menit)

```bash
# 1. Buat proyek Laravel 11 baru
composer create-project laravel/laravel monika "^11.0"
cd monika

# 2. Pasang Livewire 3
composer require livewire/livewire:"^3.0"

# 3. Salin SELURUH ISI folder overlay ini ke dalam folder monika/
#    Timpa (replace) file yang sudah ada saat ditanya. File yang tertimpa:
#    - bootstrap/app.php
#    - routes/web.php
#    - app/Models/User.php
#    - app/Providers/AppServiceProvider.php
#    - database/seeders/DatabaseSeeder.php

# 4. Konfigurasi database di file .env
#    DB_CONNECTION=mysql
#    DB_DATABASE=monika        <- database yang Anda buat
#    DB_USERNAME=root          <- sesuaikan
#    DB_PASSWORD=              <- sesuaikan
#    (tambahkan juga: APP_LOCALE=id  dan  APP_FAKER_LOCALE=id_ID)

# 5. Migrasi + data contoh, link storage, jalankan
php artisan key:generate     # jika belum otomatis
php artisan migrate --seed
php artisan storage:link
php artisan serve
```

Buka http://127.0.0.1:8000 lalu login:

| Peran | Email | Password |
|---|---|---|
| Admin | admin@monika.test | admin123 |
| Staff | budi@monika.test | staff123 |
| Staff | sari@monika.test | staff123 |

**Ganti semua password bawaan** lewat menu Pengguna setelah login pertama.

Catatan: **tidak perlu npm/vite** — styling memakai `public/assets/style.css`
(CSS kustom siap pakai). Migrasi ke Tailwind build bisa dilakukan belakangan
tanpa mengubah struktur.

---

## B. Alternatif: rakit dengan Claude Code

Jika memakai Claude Code, cukup beri instruksi:

> Buat proyek Laravel 11 baru bernama `monika`, pasang `livewire/livewire:^3.0`,
> lalu salin seluruh isi folder overlay `monika-laravel-fase1/` ke dalam proyek
> (timpa file yang sama). Set `.env` ke database MySQL lokal, jalankan
> `php artisan migrate --seed` dan `php artisan storage:link`, lalu jalankan
> checklist verifikasi di bagian D file SETUP.md.

---

## C. Deploy ke Hostinger

Laravel butuh document root menunjuk ke folder `public/` — berbeda dari PHP
native yang tinggal ekstrak.

**Paket Business / Cloud (ada SSH):**
1. Buat database MySQL di hPanel, catat kredensialnya.
2. Upload proyek (hasil rakitan lengkap dengan folder `vendor/`) ke luar
   `public_html`, misalnya ke `~/monika/`. Alternatif: upload tanpa `vendor/`
   lalu jalankan `composer install --no-dev` via SSH.
3. Isi `.env` produksi: kredensial DB, `APP_ENV=production`, `APP_DEBUG=false`,
   `APP_URL=https://domainanda.com`.
4. Via SSH: `php artisan migrate --seed && php artisan storage:link
   && php artisan config:cache`.
5. Arahkan document root domain/subdomain ke `~/monika/public`
   (hPanel → Websites → pengaturan domain). Jika paket tidak mengizinkan
   ubah document root: hapus folder `public_html`, lalu buat symlink
   `ln -s ~/monika/public ~/public_html`.

**Paket tanpa SSH:** rakit di komputer lokal sampai jalan, upload seluruh
folder (termasuk `vendor/`) via File Manager, lalu terapkan langkah 3 dan 5.
Migrasi dijalankan sekali dari lokal dengan `.env` menunjuk ke DB remote
(aktifkan Remote MySQL di hPanel) — atau minta bantuan saya membuat skrip
migrasi sekali-pakai.

---

## D. Checklist Verifikasi (jalankan setelah rakit)

Skenario yang sama dengan pengujian versi native — semuanya harus lulus:

1. **Gating**: buka proyek "Instalasi VRV Gedung Kantor A" (SPH Draft) —
   tombol "Lanjut" harus disabled dengan daftar syarat kurang.
2. **Override**: sebagai admin, buka "PM HVAC Kontrak Tahunan" (Menunggu PO) →
   Override dengan alasan < 10 karakter harus DITOLAK; dengan alasan panjang
   harus maju ke Pengerjaan + muncul badge "menyusul" + tercatat OVERRIDE
   kuning di timeline.
3. **Dokumen menyusul**: panel dashboard "Dokumen Menyusul" menampilkan proyek
   Chiller Cikarang (PO menyusul, seed bawaan); tombol "Tandai Lengkap"
   (admin) menghapusnya.
4. **Guard pembayaran**: proyek "Overhaul AHU RS" (Menunggu Pembayaran, baru
   dibayar 50%) — override ke Selesai harus GAGAL dengan pesan "tidak bisa
   dilewati, walau dengan override".
5. **Guard arsip**: proyek dengan hutang dokumen terbuka tidak boleh bisa
   mencapai status Selesai.
6. **Task**: tambah task, toggle selesai — progress bar berubah; semua task
   done membuka tombol lanjut ke BAST.
7. **Akses staff**: login budi@monika.test — menu Pengguna/Pengaturan tidak
   tampil, URL /pengguna balas 403, tombol Override tidak muncul.
8. **Rollback & batal** (admin): keduanya wajib alasan ≥ 10 karakter dan
   tercatat di timeline.

---

## E. Struktur Overlay

```
app/
  Http/Controllers/AuthController.php   Login/logout (tanpa Breeze, tanpa npm)
  Http/Middleware/EnsureAdmin.php       Guard peran admin
  Livewire/                             Dashboard, Projects (Index/Form/Detail),
                                        Clients, Admin (Users, CompanySettings)
  Models/                               14 model + relasi lengkap
  Providers/AppServiceProvider.php      Locale id + Blade directive @rupiah @tgl
  Services/ProjectStateService.php      ★ Jantung aplikasi — semua transisi status
  Support/Fmt.php                       Format Rupiah & tanggal Indonesia
bootstrap/app.php                       Registrasi middleware 'admin'
database/
  migrations/...create_monika_tables    Semua tabel (termasuk Fase 2–4)
  seeders/MonikaSeeder.php              3 user, 3 klien, 6 proyek contoh
public/assets/style.css                 Desain MONIKA (tanpa build step)
resources/views/                        Layout, komponen stepper/badge, login,
                                        semua view Livewire
routes/web.php                          Rute lengkap Fase 1
```

Aturan emas untuk pengembangan Fase 2 dst.: **jangan pernah mengubah
`projects.status` di luar `ProjectStateService`** — modul SPH/PO/BAST/Invoice
nanti cukup memanggil `advance()` dan `resolveRequirement()`.
