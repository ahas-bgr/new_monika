<?php

use App\Http\Controllers\AuthController;
use App\Livewire\Admin\CompanySettings;
use App\Livewire\Admin\Users;
use App\Livewire\Clients;
use App\Livewire\Costing\Form as CostingForm;
use App\Livewire\Costing\Index as CostingIndex;
use App\Livewire\Dashboard;
use App\Livewire\Projects\Detail as ProjectDetail;
use App\Livewire\Projects\Form as ProjectForm;
use App\Livewire\Projects\Index as ProjectIndex;
use App\Livewire\TenderDocuments;
use Illuminate\Support\Facades\Route;

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.attempt');
});

Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::get('/', fn () => redirect()->route('dashboard'));
    Route::get('/dashboard', Dashboard::class)->name('dashboard');

    Route::get('/proyek', ProjectIndex::class)->name('projects.index');
    Route::get('/proyek/baru', ProjectForm::class)->name('projects.create');
    Route::get('/proyek/{project}/edit', ProjectForm::class)->name('projects.edit');
    Route::get('/proyek/{project}', ProjectDetail::class)->name('projects.show');

    Route::get('/klien', Clients::class)->name('clients.index');

    Route::get('/dokumen-tender', TenderDocuments::class)->name('tender.index');

    Route::get('/costing', CostingIndex::class)->name('costing.index');
    Route::get('/costing/baru', CostingForm::class)->name('costing.create');
    Route::get('/costing/{costing}/edit', CostingForm::class)->name('costing.edit');

    Route::middleware('admin')->group(function () {
        Route::get('/pengguna', Users::class)->name('users.index');
        Route::get('/pengaturan', CompanySettings::class)->name('settings');
    });
});
